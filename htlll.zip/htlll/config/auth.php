<?php
// Authentication functions for the application

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
function redirectIfNotLoggedIn() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// Verify staff login
function loginStaff($username, $password, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM staff WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Update last login time
            $updateStmt = $pdo->prepare("UPDATE staff SET last_login = NOW() WHERE id_staff = :id");
            $updateStmt->execute(['id' => $user['id_staff']]);
            
            $_SESSION['user_id'] = $user['id_staff'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['user_type'] = 'staff';
            
            return true;
        }
        return false;
    } catch (PDOException $e) {
        return false;
    }
}

// Verify guest login
function loginTamu($username, $password, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM tamu WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();
        
        if ($user && $user['password'] == $password) { // Note: In real-world, use password_hash and password_verify
            $_SESSION['user_id'] = $user['id_tamu'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_role'] = 'Tamu';
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['user_type'] = 'tamu';
            
            return true;
        }
        return false;
    } catch (PDOException $e) {
        return false;
    }
}

// Register new guest
function registerTamu($data, $pdo) {
    try {
        // Check if username already exists
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM tamu WHERE username = :username OR no_ktp = :no_ktp");
        $checkStmt->execute([
            'username' => $data['username'],
            'no_ktp' => $data['no_ktp']
        ]);
        
        if ($checkStmt->fetchColumn() > 0) {
            return ['status' => false, 'message' => 'Username atau No KTP sudah terdaftar'];
        }
        
        // Insert new guest
        $stmt = $pdo->prepare("
            INSERT INTO tamu (nama_lengkap, no_ktp, no_hp, email, alamat, tanggal_daftar, username, password) 
            VALUES (:nama_lengkap, :no_ktp, :no_hp, :email, :alamat, CURDATE(), :username, :password)
        ");
        
        $stmt->execute([
            'nama_lengkap' => $data['nama_lengkap'],
            'no_ktp' => $data['no_ktp'],
            'no_hp' => $data['no_hp'],
            'email' => $data['email'],
            'alamat' => $data['alamat'],
            'username' => $data['username'],
            'password' => $data['password'] // In real-world, use password_hash
        ]);
        
        return ['status' => true, 'message' => 'Pendaftaran berhasil, silahkan login'];
    } catch (PDOException $e) {
        return ['status' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
    }
}

// Check for specific role access
function requireRole($roles) {
    if (!isset($_SESSION['user_role'])) {
        header('Location: login.php');
        exit;
    }
    
    if (!is_array($roles)) {
        $roles = [$roles];
    }
    
    if (!in_array($_SESSION['user_role'], $roles)) {
        header('Location: index.php?page=error&message=Anda tidak memiliki akses ke halaman ini');
        exit;
    }
}

// Logout function
function logout() {
    // Unset all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
    
    // Redirect to login page
    header('Location: login.php');
    exit;
}
?>
