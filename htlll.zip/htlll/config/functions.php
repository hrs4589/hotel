<?php
/**
 * Helper functions for the hotel management system
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check if user is logged in as staff
 * @return bool
 */
function isStaffLoggedIn() {
    return isset($_SESSION['staff_id']) && !empty($_SESSION['staff_id']);
}

/**
 * Check if user is logged in as guest
 * @return bool
 */
function isGuestLoggedIn() {
    return isset($_SESSION['tamu_id']) && !empty($_SESSION['tamu_id']);
}

/**
 * Check if logged in staff has specified role
 * @param string|array $roles Role or array of roles to check
 * @return bool
 */
function hasRole($roles) {
    if (!isStaffLoggedIn()) {
        return false;
    }
    
    if (is_string($roles)) {
        $roles = [$roles];
    }
    
    return in_array($_SESSION['role'], $roles);
}

/**
 * Get current page from URL parameter
 * @return string
 */
function getCurrentPage() {
    return isset($_GET['page']) ? $_GET['page'] : 'dashboard';
}

/**
 * Redirect to a different page
 * @param string $url
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Sanitize user input
 * @param string $data
 * @return string
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Format date to readable format
 * @param string $date
 * @return string
 */
function formatDate($date) {
    return date("d F Y", strtotime($date));
}

/**
 * Format currency
 * @param float $amount
 * @return string
 */
function formatCurrency($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Get list of room types
 * @return array
 */
function getRoomTypes() {
    return ['Standard', 'Deluxe', 'Suite'];
}

/**
 * Get list of staff roles
 * @return array
 */
function getStaffRoles() {
    return ['Resepsionis', 'Housekeeping', 'Manajer'];
}

/**
 * Get list of room statuses
 * @return array
 */
function getRoomStatuses() {
    return ['Tersedia', 'Dipesan', 'Maintenance'];
}

/**
 * Get list of booking statuses
 * @return array
 */
function getBookingStatuses() {
    return ['Menunggu', 'Dikonfirmasi', 'Check-In', 'Check-Out', 'Dibatalkan'];
}

/**
 * Get list of payment methods
 * @return array
 */
function getPaymentMethods() {
    return ['Transfer', 'Tunai'];
}

/**
 * Get list of penalty statuses
 * @return array
 */
function getPenaltyStatuses() {
    return ['Belum Dibayar', 'Lunas'];
}

/**
 * Upload file to server
 * @param array $file The $_FILES array element
 * @param string $folder Target folder (relative to uploads/)
 * @return string|false The filename if success, false if failed
 */
function uploadFile($file, $folder) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    // Create folder if not exists
    $targetDir = "uploads/$folder/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    // Generate unique filename
    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $newFilename = uniqid() . "." . $fileExtension;
    $targetFile = $targetDir . $newFilename;
    
    // Check file type (only allow images)
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($fileExtension, $allowedTypes)) {
        return false;
    }
    
    // Upload file
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return $newFilename;
    }
    
    return false;
}

/**
 * Calculate number of nights between two dates
 * @param string $checkin
 * @param string $checkout
 * @return int
 */
function calculateNights($checkin, $checkout) {
    $checkinDate = new DateTime($checkin);
    $checkoutDate = new DateTime($checkout);
    $interval = $checkinDate->diff($checkoutDate);
    return $interval->days;
}

/**
 * Generate password hash
 * @param string $password
 * @return string
 */
function generatePasswordHash($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password hash
 * @param string $password
 * @param string $hash
 * @return bool
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Check if a user has permission to access a page
 * @param string $page
 * @return bool
 */
function hasPageAccess($page) {
    // Guest pages
    $guestPages = ['guest/dashboard', 'guest/pemesanan', 'guest/profile'];
    if (in_array($page, $guestPages)) {
        return isGuestLoggedIn();
    }
    
    // Pages accessible to all staff
    $allStaffPages = ['dashboard', 'profile'];
    if (in_array($page, $allStaffPages)) {
        return isStaffLoggedIn();
    }
    
    // Role-specific pages
    $pagePermissions = [
        'kamar' => ['Resepsionis', 'Manajer'],
        'tamu' => ['Resepsionis', 'Manajer'],
        'pemesanan' => ['Resepsionis', 'Manajer'],
        'denda' => ['Resepsionis', 'Manajer'],
        'staff' => ['Manajer'],
        'reports' => ['Manajer'],
        'housekeeping' => ['Housekeeping', 'Manajer'],
    ];
    
    if (isset($pagePermissions[$page])) {
        return hasRole($pagePermissions[$page]);
    }
    
    // Default to no access
    return false;
}

/**
 * Get user's full name
 * @return string
 */
function getUserFullName() {
    if (isStaffLoggedIn()) {
        return $_SESSION['fullname'];
    } elseif (isGuestLoggedIn()) {
        return $_SESSION['tamu_name'];
    }
    return 'Guest';
}

/**
 * Get user's role
 * @return string
 */
function getUserRole() {
    if (isStaffLoggedIn()) {
        return $_SESSION['role'];
    } elseif (isGuestLoggedIn()) {
        return 'Tamu';
    }
    return '';
}

/**
 * Update last login time for staff
 * @param int $staffId
 * @param PDO $pdo
 */
function updateLastLogin($staffId, $pdo) {
    $stmt = $pdo->prepare("UPDATE staff SET last_login = NOW() WHERE id_staff = ?");
    $stmt->execute([$staffId]);
}

/**
 * Calculate total price for a booking
 * @param float $pricePerNight
 * @param string $checkin
 * @param string $checkout
 * @return float
 */
function calculateTotalPrice($pricePerNight, $checkin, $checkout) {
    $nights = calculateNights($checkin, $checkout);
    return $pricePerNight * $nights;
}
