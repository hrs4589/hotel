<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Heritage Borobudur - Hotel & Resort</title>
  
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
  <!-- Custom CSS -->
  <style>
    :root {
      --primary-color: #8B5A2B;
      --secondary-color: #D2B48C;
      --accent-color: #A0522D;
      --light-color: #F5F5DC;
      --dark-color: #3E2723;
    }
    
    body {
      font-family: 'Poppins', sans-serif;
      color: var(--dark-color);
      background-color: var(--light-color);
      overflow-x: hidden;
    }
    
    h1, h2, h3, h4, h5 {
      font-family: 'Playfair Display', serif;
      color: var(--primary-color);
    }
    
    .navbar {
      background-color: rgba(255, 255, 255, 0.9);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
    }
    
    .navbar.scrolled {
      background-color: rgba(255, 255, 255, 0.95);
    }
    
    .nav-link {
      color: var(--dark-color);
      font-weight: 500;
      margin: 0 10px;
      position: relative;
    }
    
    .nav-link:after {
      content: '';
      position: absolute;
      width: 0;
      height: 2px;
      background: var(--primary-color);
      bottom: 0;
      left: 0;
      transition: width 0.3s;
    }
    
    .nav-link:hover:after {
      width: 100%;
    }
    
    .hero-section {
      background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
      background-size: cover;
      background-position: center;
      background-attachment: fixed;
      height: 100vh;
      min-height: 600px;
      color: white;
      display: flex;
      align-items: center;
      position: relative;
    }
    
    .hero-content {
      z-index: 2;
    }
    
    .hero-title {
      font-size: 4rem;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
      margin-bottom: 1.5rem;
    }
    
    .hero-subtitle {
      font-size: 1.5rem;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
      margin-bottom: 2rem;
      max-width: 700px;
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      padding: 10px 25px;
      font-weight: 500;
      transition: all 0.3s;
    }
    
    .btn-primary:hover {
      background-color: var(--accent-color);
      border-color: var(--accent-color);
      transform: translateY(-3px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
    
    .section-title {
      position: relative;
      margin-bottom: 3rem;
      text-align: center;
    }
    
    .section-title:after {
      content: '';
      position: absolute;
      width: 80px;
      height: 3px;
      background: var(--primary-color);
      bottom: -15px;
      left: 50%;
      transform: translateX(-50%);
    }
    
    .about-section {
      padding: 100px 0;
      background-color: white;
    }
    
    .about-img {
      border-radius: 10px;
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: all 0.5s;
    }
    
    .about-img:hover {
      transform: scale(1.03);
    }
    
    .feature-box {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
      transition: all 0.3s;
      height: 100%;
      text-align: center;
    }
    
    .feature-box:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    
    .feature-icon {
      font-size: 3rem;
      color: var(--primary-color);
      margin-bottom: 1.5rem;
    }
    
    .rooms-section {
      padding: 100px 0;
      background-color: var(--light-color);
    }
    
    .room-card {
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      margin-bottom: 30px;
      transition: all 0.3s;
      background: white;
    }
    
    .room-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
    }
    
    .room-img {
      height: 250px;
      object-fit: cover;
      width: 100%;
    }
    
    .room-body {
      padding: 20px;
    }
    
    .room-title {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }
    
    .room-price {
      color: var(--accent-color);
      font-weight: 700;
      font-size: 1.2rem;
    }
    
    .facilities-section {
      padding: 100px 0;
      background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
      background-size: cover;
      background-position: center;
      background-attachment: fixed;
      color: white;
    }
    
    .facility-item {
      text-align: center;
      padding: 30px 15px;
      margin-bottom: 30px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(5px);
      border-radius: 10px;
      transition: all 0.3s;
    }
    
    .facility-item:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-5px);
    }
    
    .facility-icon {
      font-size: 2.5rem;
      margin-bottom: 15px;
      color: var(--secondary-color);
    }
    
    .testimonial-section {
      padding: 100px 0;
      background-color: white;
    }
    
    .testimonial-card {
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
      margin: 15px;
      background: var(--light-color);
    }
    
    .testimonial-text {
      font-style: italic;
      margin-bottom: 20px;
    }
    
    .testimonial-author {
      font-weight: 700;
      color: var(--primary-color);
    }
    
    .contact-section {
      padding: 100px 0;
      background-color: var(--light-color);
    }
    
    .contact-info {
      margin-bottom: 30px;
    }
    
    .contact-icon {
      font-size: 1.5rem;
      color: var(--primary-color);
      margin-right: 15px;
    }
    
    .footer {
      background-color: var(--dark-color);
      color: white;
      padding: 60px 0 20px;
    }
    
    .footer-logo {
      font-family: 'Playfair Display', serif;
      font-size: 2rem;
      margin-bottom: 20px;
    }
    
    .footer-links h5 {
      color: var(--secondary-color);
      margin-bottom: 20px;
    }
    
    .footer-links a {
      color: white;
      text-decoration: none;
      display: block;
      margin-bottom: 10px;
      transition: all 0.3s;
    }
    
    .footer-links a:hover {
      color: var(--secondary-color);
      padding-left: 5px;
    }
    
    .social-icons a {
      display: inline-block;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.1);
      color: white;
      border-radius: 50%;
      text-align: center;
      line-height: 40px;
      margin-right: 10px;
      transition: all 0.3s;
    }
    
    .social-icons a:hover {
      background: var(--primary-color);
      transform: translateY(-5px);
    }
    
    .copyright {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 20px;
      margin-top: 40px;
      text-align: center;
    }
    
    /* Animations */
    .animate-up {
      animation: fadeInUp 1s both;
    }
    
    .animate-delay-1 {
      animation-delay: 0.2s;
    }
    
    .animate-delay-2 {
      animation-delay: 0.4s;
    }
    
    .animate-delay-3 {
      animation-delay: 0.6s;
    }
    
    /* Responsive adjustments */
    @media (max-width: 992px) {
      .hero-title {
        font-size: 3rem;
      }
      
      .hero-subtitle {
        font-size: 1.2rem;
      }
    }
    
    @media (max-width: 768px) {
      .hero-title {
        font-size: 2.5rem;
      }
      
      .navbar-collapse {
        background: rgba(255, 255, 255, 0.95);
        padding: 20px;
        border-radius: 10px;
        margin-top: 10px;
      }
    }
    
    @media (max-width: 576px) {
      .hero-title {
        font-size: 2rem;
      }
      
      .hero-subtitle {
        font-size: 1rem;
      }
      
      .section-title {
        font-size: 1.8rem;
      }
    }
  </style>
</head>

<body>
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">
        <span style="font-family: 'Playfair Display', serif; font-size: 1.5rem; color: var(--primary-color);">Magelang Hotel</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="#home">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#about">Tentang Kami</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#rooms">Kamar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#facilities">Fasilitas</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contact">Kontak</a>
          </li>
          <li class="nav-item ms-lg-3">
            <a class="btn btn-primary" href="login.php">LOGIN</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero-section" id="home">
    <div class="container">
      <div class="hero-content animate__animated animate__fadeIn">
        <h1 class="hero-title animate-up">Magelang Hotel</h1>
        <p class="hero-subtitle animate-up animate-delay-1">Pengalaman menginap yang tak terlupakan dengan nuansa kemegahan Candi Borobudur yang klasik dan elegan</p>
        <a href="#booking" class="btn btn-primary btn-lg animate-up animate-delay-2">Pesan Kamar</a>
      </div>
    </div>
  </section>

  <!-- About Section -->
  <section class="about-section" id="about">
    <div class="container">
      <h2 class="section-title">Tentang Kami</h2>
      <div class="row align-items-center">
        <div class="col-lg-6 mb-4 mb-lg-0">
          <img src="https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" alt="Heritage Borobudur" class="img-fluid about-img">
        </div>
        <div class="col-lg-6">
          <h3>Pengalaman Budaya Jawa yang Autentik</h3>
          <p>Magelang Hotel adalah hotel mewah yang terinspirasi oleh keagungan Candi Borobudur, menggabungkan kemewahan modern dengan warisan budaya Jawa kuno. Terletak di lokasi strategis dengan pemandangan langsung ke candi, kami menawarkan pengalaman menginap yang tak terlupakan.</p>
          <p>Setiap detail di hotel kami dirancang untuk mencerminkan keindahan arsitektur Jawa kuno, dari ornamen ukiran kayu hingga tata letak yang harmonis dengan alam. Kami bangga menjadi jembatan antara warisan budaya masa lalu dan kenyamanan masa kini.</p>
          <div class="row mt-4">
            <div class="col-md-6 mb-3">
              <div class="feature-box">
                <div class="feature-icon">
                  <i class="fas fa-umbrella-beach"></i>
                </div>
                <h5>Lokasi Eksklusif</h5>
                <p>Hanya 5 menit berjalan kaki dari Candi Borobudur</p>
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <div class="feature-box">
                <div class="feature-icon">
                  <i class="fas fa-spa"></i>
                </div>
                <h5>Layanan Spa</h5>
                <p>Perawatan tradisional Jawa untuk relaksasi total</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Rooms Section -->
  <section class="rooms-section" id="rooms">
    <div class="container">
      <h2 class="section-title">Pilihan Kamar Kami</h2>
      <div class="row">
        <div class="col-md-6 col-lg-4">
          <div class="room-card">
          <img src="https://images.pexels.com/photos/237371/pexels-photo-237371.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="Suite" class="room-img">
          <div class="room-body">
              <h4 class="room-title">Kamar Standard</h4>
              <p>Kamar luas dengan sentuhan tradisional Jawa dan fasilitas modern untuk kenyamanan maksimal.</p>
              
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="room-card">
            <img src="https://images.unsplash.com/photo-1564078516393-cf04bd966897?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" alt="Suite Room" class="room-img">
            <div class="room-body">
              <h4 class="room-title">Kamar Deluxe</h4>
              <p>Kamar mewah dengan balkon pribadi yang menghadap langsung ke Candi Borobudur.</p>
             
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="room-card">
            <img src="https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" alt="Presidential Suite" class="room-img">
            <div class="room-body">
              <h4 class="room-title">Kamar Suite </h4>
              <p>Akomodasi paling eksklusif kami dengan layanan butler pribadi dan kolam renang pribadi.</p>
            
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Facilities Section -->
  <section class="facilities-section" id="facilities">
    <div class="container">
      <h2 class="section-title text-white">Fasilitas Unggulan</h2>
      <div class="row">
        <div class="col-md-6 col-lg-3">
          <div class="facility-item">
            <div class="facility-icon">
              <i class="fas fa-swimming-pool"></i>
            </div>
            <h4>Kolam Renang </h4>
            <p>Kolam renang dengan pemandangan langsung ke Candi Borobudur</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="facility-item">
            <div class="facility-icon">
              <i class="fas fa-utensils"></i>
            </div>
            <h4>Restoran Borobudur</h4>
            <p>Menikmati hidangan tradisional Jawa dengan sentuhan modern</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="facility-item">
            <div class="facility-icon">
              <i class="fas fa-spa"></i>
            </div>
            <h4>Spa Tradisional</h4>
            <p>Perawatan tubuh dengan teknik dan bahan alami khas Jawa</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="facility-item">
            <div class="facility-icon">
              <i class="fas fa-bus"></i>
            </div>
            <h4>Tur Eksklusif</h4>
            <p>Tur privat ke Candi Borobudur dengan pemandu ahli</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimonial Section -->
  <section class="testimonial-section" id="testimonials">
    <div class="container">
      <h2 class="section-title">Apa Kata Tamu Kami</h2>
      <div class="row">
        <div class="col-lg-4">
          <div class="testimonial-card">
            <p class="testimonial-text">"Pengalaman menginap yang luar biasa! Bangun pagi dengan pemandangan Candi Borobudur dari balkon kamar adalah momen yang tak terlupakan."</p>
            <div class="d-flex align-items-center">
              <img src="https://randomuser.me/api/portraits/women/32.jpg" alt="Guest" class="rounded-circle me-3" width="60">
              <div>
                <h5 class="testimonial-author mb-1">Sarah Wijaya</h5>
                <small>Jakarta</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="testimonial-card">
            <p class="testimonial-text">"Pelayanan sangat personal dan hangat. Desain interior yang memadukan modern dan tradisional Jawa sungguh memukau."</p>
            <div class="d-flex align-items-center">
              <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="Guest" class="rounded-circle me-3" width="60">
              <div>
                <h5 class="testimonial-author mb-1">Budi Santoso</h5>
                <small>Surabaya</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="testimonial-card">
            <p class="testimonial-text">"Spa tradisionalnya adalah yang terbaik yang pernah saya coba. Staf sangat profesional dan fasilitasnya sangat lengkap. Sangat disarankan."</p>
            <div class="d-flex align-items-center">
              <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Guest" class="rounded-circle me-3" width="60">
              <div>
                <h5 class="testimonial-author mb-1">Dewi Lestari</h5>
                <small>Bali</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Section -->
<section class="contact-section" id="contact">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 mb-5 mb-lg-0">
        <h2 class="section-title">Hubungi Kami</h2>
        <div class="contact-info">
          <div class="d-flex mb-4">
            <div class="contact-icon">
              <i class="fas fa-map-marker-alt"></i>
            </div>
            <div>
              <h5>Lokasi</h5>
              <p>Jl. Badrawati No. 1, Borobudur, Magelang, Jawa Tengah</p>
            </div>
          </div>
          <div class="d-flex mb-4">
            <div class="contact-icon">
              <i class="fas fa-phone-alt"></i>
            </div>
            <div>
              <h5>Telepon</h5>
              <p>+62 123 4567 890</p>
            </div>
          </div>
          <div class="d-flex mb-4">
            <div class="contact-icon">
              <i class="fas fa-envelope"></i>
            </div>
            <div>
              <h5>Email</h5>
              <p>info@heritageborobudur.com</p>
            </div>
          </div>
        </div>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card h-100 border-0 shadow-sm">
          <div class="card-body p-5 d-flex flex-column justify-content-center" style="background-color: rgba(139, 90, 43, 0.05);">
            <div class="text-center">
              <i class="fas fa-calendar-alt fa-3x mb-4" style="color: var(--primary-color);"></i>
              <h3 class="mb-3">Jam Operasional</h3>
              <div class="mb-4">
                <p class="mb-1"><strong>Senin - Jumat:</strong> 08.00 - 20.00 WIB</p>
                <p class="mb-1"><strong>Sabtu - Minggu:</strong> 08.00 - 22.00 WIB</p>
                <p><strong>Hari Libur:</strong> 24 Jam</p>
              </div>
              <div class="pt-3 border-top">
                <i class="fas fa-clock fa-2x mb-3" style="color: var(--primary-color);"></i>
                <p>Resepsionis kami siap melayani Anda selama jam operasional</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 mb-4 mb-lg-0">
          <div class="footer-logo">Magelang Hotel</div>
          <p>Hotel mewah dengan nuansa Candi Borobudur yang menawarkan pengalaman menginap tak terlupakan dengan sentuhan budaya Jawa yang autentik.</p>
        </div>
        <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
          <div class="footer-links">
            <h5>Tautan Cepat</h5>
            <a href="#home">Beranda</a>
            <a href="#about">Tentang Kami</a>
            <a href="#rooms">Kamar</a>
            <a href="#facilities">Fasilitas</a>
            <a href="#contact">Kontak</a>
          </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
          <div class="footer-links">
            <h5>Layanan</h5>
            <a href="#">Pemesanan Online</a>
            <a href="#">Tur Borobudur</a>
            <a href="#">Spa Tradisional</a>
            <a href="#">Restoran</a>
            <a href="#">Meeting Room</a>
          </div>
        </div>
        <div class="col-lg-4 col-md-4">
          <div class="footer-links">
            <h5>Informasi</h5>
            <p>Untuk memantau hotel kami bisa melalui website ini</p>
            <div class="input-group mb-3">
           
              </div>
          </div>
        </div>
      </div>
      <div class="copyright">
        <p class="mb-0">&copy; 2023 Heritage Borobudur. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <!-- Back to Top Button -->
  <a href="#" class="btn btn-primary back-to-top" style="position: fixed; bottom: 20px; right: 20px; display: none; z-index: 99;">
    <i class="fas fa-arrow-up"></i>
  </a>

  <!-- Bootstrap 5 JS Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <!-- Custom JS -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Navbar scroll effect
      window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
          document.querySelector('.navbar').classList.add('scrolled');
        } else {
          document.querySelector('.navbar').classList.remove('scrolled');
        }
        
        // Show back to top button
        if (window.scrollY > 300) {
          document.querySelector('.back-to-top').style.display = 'block';
        } else {
          document.querySelector('.back-to-top').style.display = 'none';
        }
      });
      
      // Smooth scrolling for navigation links
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
          e.preventDefault();
          
          const targetId = this.getAttribute('href');
          if (targetId === '#') return;
          
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
            window.scrollTo({
              top: targetElement.offsetTop - 70,
              behavior: 'smooth'
            });
          }
        });
      });
      
      // Form submission
      document.getElementById('bookingForm').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Terima kasih! Permintaan pemesanan Anda telah diterima. Kami akan segera menghubungi Anda untuk konfirmasi.');
        this.reset();
      });
      
      // Animation on scroll
      function animateOnScroll() {
        const elements = document.querySelectorAll('.feature-box, .room-card, .facility-item, .testimonial-card');
        
        elements.forEach(element => {
          const elementPosition = element.getBoundingClientRect().top;
          const screenPosition = window.innerHeight / 1.3;
          
          if (elementPosition < screenPosition) {
            element.classList.add('animate__animated', 'animate__fadeInUp');
          }
        });
      }
      
      window.addEventListener('scroll', animateOnScroll);
      animateOnScroll(); // Run once on page load
    });
  </script>
</body>
</html>