<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user has permission to access this page
if (!hasRole(['Resepsionis'])) {
    echo '<div class="container-fluid"><div class="alert alert-danger">You do not have permission to access this page.</div></div>';
    exit;
}

// Process form submissions
$success = $error = '';

// Process add/edit guest
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // Common form data
    $nama_lengkap = sanitize($_POST['nama_lengkap']);
    $no_ktp = sanitize($_POST['no_ktp']);
    $no_hp = sanitize($_POST['no_hp']);
    $email = sanitize($_POST['email']);
    $alamat = sanitize($_POST['alamat']);
    $username = sanitize($_POST['username']);
    
    // Validate form data
    if (empty($nama_lengkap) || empty($no_ktp) || empty($no_hp) || empty($username)) {
        $error = 'Nama lengkap, nomor KTP, nomor HP, dan username harus diisi';
    } else {
        try {
            if ($action === 'add') {
                $password = $_POST['password'];
                if (empty($password)) {
                    $error = 'Password harus diisi untuk tamu baru';
                } else {
                    // Check if username already exists
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tamu WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'Username sudah digunakan';
                    } else {
                        // Check if KTP already exists
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tamu WHERE no_ktp = ?");
                        $stmt->execute([$no_ktp]);
                        if ($stmt->fetchColumn() > 0) {
                            $error = 'Nomor KTP sudah terdaftar';
                        } else {
                            // Hash password
                            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                            
                            // Insert new guest
                            $stmt = $pdo->prepare("
                                INSERT INTO tamu (nama_lengkap, no_ktp, no_hp, email, alamat, tanggal_daftar, username, password)
                                VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?)
                            ");
                            $stmt->execute([$nama_lengkap, $no_ktp, $no_hp, $email, $alamat, $username, $hashed_password]);
                            $success = 'Tamu berhasil ditambahkan';
                        }
                    }
                }
            } elseif ($action === 'edit' && isset($_POST['id_tamu'])) {
                $id_tamu = (int)$_POST['id_tamu'];
                
                // Check if guest exists
                $stmt = $pdo->prepare("SELECT * FROM tamu WHERE id_tamu = ?");
                $stmt->execute([$id_tamu]);
                $guest = $stmt->fetch();
                
                if (!$guest) {
                    $error = 'Tamu tidak ditemukan';
                } else {
                    // Check if username already exists for another guest
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tamu WHERE username = ? AND id_tamu != ?");
                    $stmt->execute([$username, $id_tamu]);
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'Username sudah digunakan oleh tamu lain';
                    } else {
                        // Check if KTP already exists for another guest
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tamu WHERE no_ktp = ? AND id_tamu != ?");
                        $stmt->execute([$no_ktp, $id_tamu]);
                        if ($stmt->fetchColumn() > 0) {
                            $error = 'Nomor KTP sudah terdaftar untuk tamu lain';
                        } else {
                            // Update guest data
                            $stmt = $pdo->prepare("
                                UPDATE tamu 
                                SET nama_lengkap = ?, no_ktp = ?, no_hp = ?, email = ?, alamat = ?, username = ?
                                WHERE id_tamu = ?
                            ");
                            $stmt->execute([$nama_lengkap, $no_ktp, $no_hp, $email, $alamat, $username, $id_tamu]);
                            
                            // Update password if provided
                            if (!empty($_POST['password'])) {
                                $new_password = $_POST['password'];
                                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                                
                                $stmt = $pdo->prepare("UPDATE tamu SET password = ? WHERE id_tamu = ?");
                                $stmt->execute([$hashed_password, $id_tamu]);
                            }
                            
                            $success = 'Data tamu berhasil diperbarui';
                        }
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Process delete guest
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_tamu = (int)$_GET['id'];
    
    try {
        // Check if the guest can be deleted (not referenced in bookings)
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM pemesanan WHERE id_tamu = ?");
        $stmt->execute([$id_tamu]);
        if ($stmt->fetchColumn() > 0) {
            $error = 'Tamu ini tidak dapat dihapus karena memiliki riwayat pemesanan';
        } else {
            // Delete the guest
            $stmt = $pdo->prepare("DELETE FROM tamu WHERE id_tamu = ?");
            $stmt->execute([$id_tamu]);
            $success = 'Tamu berhasil dihapus';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Get all guests
try {
    $stmt = $pdo->query("SELECT * FROM tamu ORDER BY nama_lengkap");
    $guests = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $guests = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Guest Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addGuestModal">
            <i class="fas fa-plus"></i> Add New Guest
        </button>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Guest List -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Guests</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>ID Card</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Register Date</th>
                            <th>Username</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($guests)): ?>
                        <tr>
                            <td colspan="9" class="text-center">No guests found</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($guests as $guest): ?>
                            <tr>
                                <td><?= $guest['id_tamu'] ?></td>
                                <td><?= $guest['nama_lengkap'] ?></td>
                                <td><?= $guest['no_ktp'] ?></td>
                                <td><?= $guest['no_hp'] ?></td>
                                <td><?= $guest['email'] ?: 'N/A' ?></td>
                                <td><?= $guest['alamat'] ?: 'N/A' ?></td>
                                <td><?= formatDate($guest['tanggal_daftar']) ?></td>
                                <td><?= $guest['username'] ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary btn-edit" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editGuestModal"
                                            data-id="<?= $guest['id_tamu'] ?>"
                                            data-nama="<?= $guest['nama_lengkap'] ?>"
                                            data-ktp="<?= $guest['no_ktp'] ?>"
                                            data-hp="<?= $guest['no_hp'] ?>"
                                            data-email="<?= $guest['email'] ?>"
                                            data-alamat="<?= $guest['alamat'] ?>"
                                            data-username="<?= $guest['username'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="index.php?page=tamu&action=delete&id=<?= $guest['id_tamu'] ?>" class="btn btn-sm btn-danger btn-delete" onclick="return confirm('Are you sure you want to delete this guest?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<!-- Add Guest Modal -->
<div class="modal fade" id="addGuestModal" tabindex="-1" aria-labelledby="addGuestModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addGuestModalLabel">Add New Guest</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="nama_lengkap" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="no_ktp" class="form-label">ID Card Number</label>
                        <input type="text" class="form-control" id="no_ktp" name="no_ktp" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="no_hp" class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="no_hp" name="no_hp" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Address</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Guest Modal -->
<div class="modal fade" id="editGuestModal" tabindex="-1" aria-labelledby="editGuestModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editGuestModalLabel">Edit Guest</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id_tamu" id="edit_id_tamu">
                    
                    <div class="mb-3">
                        <label for="edit_nama_lengkap" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="edit_nama_lengkap" name="nama_lengkap" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_no_ktp" class="form-label">ID Card Number</label>
                        <input type="text" class="form-control" id="edit_no_ktp" name="no_ktp" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_no_hp" class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="edit_no_hp" name="no_hp" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_alamat" class="form-label">Address</label>
                        <textarea class="form-control" id="edit_alamat" name="alamat" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="edit_username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="edit_password" name="password">
                        <small class="form-text text-muted">Leave empty to keep current password</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle edit guest button clicks
    const editButtons = document.querySelectorAll('.btn-edit');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get guest data from button attributes
            const guestId = this.dataset.id;
            const guestName = this.dataset.nama;
            const guestKtp = this.dataset.ktp;
            const guestHp = this.dataset.hp;
            const guestEmail = this.dataset.email;
            const guestAlamat = this.dataset.alamat;
            const guestUsername = this.dataset.username;
            
            // Fill form fields with guest data
            document.getElementById('edit_id_tamu').value = guestId;
            document.getElementById('edit_nama_lengkap').value = guestName;
            document.getElementById('edit_no_ktp').value = guestKtp;
            document.getElementById('edit_no_hp').value = guestHp;
            document.getElementById('edit_email').value = guestEmail;
            document.getElementById('edit_alamat').value = guestAlamat;
            document.getElementById('edit_username').value = guestUsername;
            // Clear password field
            document.getElementById('edit_password').value = '';
        });
    });
});
</script>
