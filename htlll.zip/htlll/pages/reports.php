<?php
// Mencegah akses langsung ke file ini
if (!defined('DB_HOST')) {
    exit('Akses langsung dilarang');
}

// Memeriksa apakah pengguna memiliki izin untuk mengakses halaman ini
if (!hasRole('Manajer')) {
    echo '<div class="container-fluid"><div class="alert alert-danger">Anda tidak memiliki izin untuk mengakses halaman ini.</div></div>';
    exit;
}

// Menetapkan jenis laporan dan rentang tanggal default
$reportType = isset($_GET['report']) ? sanitize($_GET['report']) : 'occupancy';
$startDate = isset($_GET['start']) ? sanitize($_GET['start']) : date('Y-m-01');
$endDate = isset($_GET['end']) ? sanitize($_GET['end']) : date('Y-m-t');

// Inisialisasi variabel
$occupancyData = $revenueData = $roomTypeData = $penaltyData = [];
$dates = $occupancyRates = $revenues = $roomTypes = $bookingCounts = [];

// Fungsi untuk menghasilkan CSV
function generateCSV($headers, $data, $filename) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, $headers);
    
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

// Mendapatkan data laporan berdasarkan jenis dan rentang tanggal yang dipilih
try {
    switch ($reportType) {
        case 'occupancy':
            // Mendapatkan tingkat hunian harian
            $stmt = $pdo->prepare("
                SELECT 
                    DATE(p.tanggal_checkin) AS date,
                    COUNT(DISTINCT p.id_kamar) AS occupied_rooms,
                    (SELECT COUNT(*) FROM kamar) AS total_rooms
                FROM pemesanan p
                WHERE p.tanggal_checkin <= ? AND p.tanggal_checkout >= ?
                AND p.status IN ('Dikonfirmasi', 'Check-In', 'Check-Out')
                GROUP BY DATE(p.tanggal_checkin)
                ORDER BY date
            ");
            $stmt->execute([$endDate, $startDate]);
            $occupancyData = $stmt->fetchAll();
            
            foreach ($occupancyData as $row) {
                $dates[] = date('d M', strtotime($row['date']));
                $occupancyRates[] = round(($row['occupied_rooms'] / $row['total_rooms']) * 100, 2);
            }
            break;
            
        case 'revenue':
            // Mendapatkan pendapatan harian
            $stmt = $pdo->prepare("
                SELECT 
                    DATE(p.tanggal_checkin) AS date,
                    SUM(p.total_harga) AS daily_revenue
                FROM pemesanan p
                WHERE p.tanggal_checkin BETWEEN ? AND ?
                AND p.status IN ('Dikonfirmasi', 'Check-In', 'Check-Out')
                GROUP BY DATE(p.tanggal_checkin)
                ORDER BY date
            ");
            $stmt->execute([$startDate, $endDate]);
            $revenueData = $stmt->fetchAll();
            
            foreach ($revenueData as $row) {
                $dates[] = date('d M', strtotime($row['date']));
                $revenues[] = $row['daily_revenue'];
            }
            break;
            
        case 'room_type':
            // Mendapatkan pemesanan berdasarkan tipe kamar
            $stmt = $pdo->prepare("
                SELECT 
                    k.tipe,
                    COUNT(p.id_pemesanan) AS booking_count
                FROM pemesanan p
                JOIN kamar k ON p.id_kamar = k.id_kamar
                WHERE p.tanggal_checkin BETWEEN ? AND ?
                AND p.status IN ('Dikonfirmasi', 'Check-In', 'Check-Out')
                GROUP BY k.tipe
                ORDER BY booking_count DESC
            ");
            $stmt->execute([$startDate, $endDate]);
            $roomTypeData = $stmt->fetchAll();
            
            foreach ($roomTypeData as $row) {
                $roomTypes[] = $row['tipe'];
                $bookingCounts[] = $row['booking_count'];
            }
            break;
            
        case 'penalties':
            // Mendapatkan data denda
            $stmt = $pdo->prepare("
                SELECT 
                    d.jenis_denda,
                    COUNT(d.id_denda) AS penalty_count,
                    SUM(d.jumlah) AS total_amount,
                    d.status
                FROM denda d
                JOIN pemesanan p ON d.id_pemesanan = p.id_pemesanan
                WHERE p.tanggal_checkin BETWEEN ? AND ?
                GROUP BY d.jenis_denda, d.status
                ORDER BY total_amount DESC
            ");
            $stmt->execute([$startDate, $endDate]);
            $penaltyData = $stmt->fetchAll();
            break;
            
        default:
            $reportType = 'occupancy';
            // Default ke laporan hunian
            $stmt = $pdo->prepare("
                SELECT 
                    DATE(p.tanggal_checkin) AS date,
                    COUNT(DISTINCT p.id_kamar) AS occupied_rooms,
                    (SELECT COUNT(*) FROM kamar) AS total_rooms
                FROM pemesanan p
                WHERE p.tanggal_checkin <= ? AND p.tanggal_checkout >= ?
                AND p.status IN ('Dikonfirmasi', 'Check-In', 'Check-Out')
                GROUP BY DATE(p.tanggal_checkin)
                ORDER BY date
            ");
            $stmt->execute([$endDate, $startDate]);
            $occupancyData = $stmt->fetchAll();
            
            foreach ($occupancyData as $row) {
                $dates[] = date('d M', strtotime($row['date']));
                $occupancyRates[] = round(($row['occupied_rooms'] / $row['total_rooms']) * 100, 2);
            }
            break;
    }
    
    // Mendapatkan statistik ringkasan
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(id_pemesanan) AS total_bookings,
            SUM(total_harga) AS total_revenue,
            AVG(total_harga) AS avg_booking_value,
            AVG(DATEDIFF(tanggal_checkout, tanggal_checkin)) AS avg_stay_length
        FROM pemesanan
        WHERE tanggal_checkin BETWEEN ? AND ?
        AND status IN ('Dikonfirmasi', 'Check-In', 'Check-Out')
    ");
    $stmt->execute([$startDate, $endDate]);
    $summaryStats = $stmt->fetch();
    
    // Mendapatkan ringkasan denda
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(d.id_denda) AS total_penalties,
            SUM(d.jumlah) AS total_penalty_amount,
            SUM(CASE WHEN d.status = 'Lunas' THEN d.jumlah ELSE 0 END) AS paid_penalty_amount,
            SUM(CASE WHEN d.status = 'Belum Dibayar' THEN d.jumlah ELSE 0 END) AS unpaid_penalty_amount
        FROM denda d
        JOIN pemesanan p ON d.id_pemesanan = p.id_pemesanan
        WHERE p.tanggal_checkin BETWEEN ? AND ?
    ");
    $stmt->execute([$startDate, $endDate]);
    $penaltySummary = $stmt->fetch();
    
    // Memproses permintaan ekspor
    if (isset($_GET['export']) && $_GET['export'] === 'true') {
        $filename = 'laporan_hotel_' . $reportType . '_' . date('Ymd');
        
        switch ($reportType) {
            case 'occupancy':
                $headers = ['Tanggal', 'Kamar Terisi', 'Total Kamar', 'Tingkat Hunian (%)'];
                $data = [];
                foreach ($occupancyData as $row) {
                    $data[] = [
                        date('d M Y', strtotime($row['date'])),
                        $row['occupied_rooms'],
                        $row['total_rooms'],
                        round(($row['occupied_rooms'] / $row['total_rooms']) * 100, 2)
                    ];
                }
                generateCSV($headers, $data, $filename);
                break;
                
            case 'revenue':
                $headers = ['Tanggal', 'Pendapatan Harian'];
                $data = [];
                foreach ($revenueData as $row) {
                    $data[] = [
                        date('d M Y', strtotime($row['date'])),
                        $row['daily_revenue']
                    ];
                }
                generateCSV($headers, $data, $filename);
                break;
                
            case 'room_type':
                $headers = ['Tipe Kamar', 'Jumlah Pemesanan'];
                $data = [];
                foreach ($roomTypeData as $row) {
                    $data[] = [
                        $row['tipe'],
                        $row['booking_count']
                    ];
                }
                generateCSV($headers, $data, $filename);
                break;
                
            case 'penalties':
                $headers = ['Jenis Denda', 'Jumlah', 'Total Jumlah', 'Status'];
                $data = [];
                foreach ($penaltyData as $row) {
                    $data[] = [
                        $row['jenis_denda'],
                        $row['penalty_count'],
                        $row['total_amount'],
                        $row['status']
                    ];
                }
                generateCSV($headers, $data, $filename);
                break;
        }
    }
    
} catch (PDOException $e) {
    $error = 'Kesalahan database: ' . $e->getMessage();
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Laporan & Analitik</h1>
        <a href="index.php?page=reports&report=<?= $reportType ?>&start=<?= $startDate ?>&end=<?= $endDate ?>&export=true" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-download fa-sm text-white-50"></i> Ekspor Laporan (CSV)
        </a>
    </div>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Report Filter -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filter Laporan</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="form-inline">
                <input type="hidden" name="page" value="reports">
                
                <div class="form-group mb-2 mr-3">
                    <label for="report" class="mr-2">Jenis Laporan:</label>
                    <select class="form-control" id="report" name="report">
                        <option value="occupancy" <?= $reportType === 'occupancy' ? 'selected' : '' ?>>Tingkat Hunian</option>
                        <option value="revenue" <?= $reportType === 'revenue' ? 'selected' : '' ?>>Analisis Pendapatan</option>
                        <option value="room_type" <?= $reportType === 'room_type' ? 'selected' : '' ?>>Kinerja Tipe Kamar</option>
                        <option value="penalties" <?= $reportType === 'penalties' ? 'selected' : '' ?>>Laporan Denda</option>
                    </select>
                </div>
                
                <div class="form-group mb-2 mr-3">
                    <label for="start" class="mr-2">Tanggal Mulai:</label>
                    <input type="date" class="form-control" id="start" name="start" value="<?= $startDate ?>">
                </div>
                
                <div class="form-group mb-2 mr-3">
                    <label for="end" class="mr-2">Tanggal Selesai:</label>
                    <input type="date" class="form-control" id="end" name="end" value="<?= $endDate ?>">
                </div>
                
                <button type="submit" class="btn btn-primary mb-2">Terapkan Filter</button>
            </form>
        </div>
    </div>

    <!-- Summary Stats -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Pemesanan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($summaryStats['total_bookings']) ? $summaryStats['total_bookings'] : 0 ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Total Pendapatan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($summaryStats['total_revenue']) ? formatCurrency($summaryStats['total_revenue']) : formatCurrency(0) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Rata-rata Lama Menginap</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($summaryStats['avg_stay_length']) ? round($summaryStats['avg_stay_length'], 1) : 0 ?> hari</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Rata-rata Nilai Pemesanan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($summaryStats['avg_booking_value']) ? formatCurrency($summaryStats['avg_booking_value']) : formatCurrency(0) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Report Content -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?php 
                switch ($reportType) {
                    case 'occupancy': echo 'Laporan Tingkat Hunian'; break;
                    case 'revenue': echo 'Analisis Pendapatan'; break;
                    case 'room_type': echo 'Kinerja Tipe Kamar'; break;
                    case 'penalties': echo 'Laporan Denda'; break;
                }
                ?>
                (<?= date('d M Y', strtotime($startDate)) ?> - <?= date('d M Y', strtotime($endDate)) ?>)
            </h6>
        </div>
        <div class="card-body">
            <?php if ($reportType === 'occupancy'): ?>
                <div class="chart-area">
                    <canvas id="reportChart"></canvas>
                </div>
            <?php elseif ($reportType === 'revenue'): ?>
                <div class="chart-area">
                    <canvas id="reportChart"></canvas>
                </div>
            <?php elseif ($reportType === 'room_type'): ?>
                <div class="chart-pie pt-4 pb-2">
                    <canvas id="roomTypeChart"></canvas>
                </div>
                <div class="mt-4 text-center small">
                    <?php foreach ($roomTypes as $index => $type): ?>
                    <span class="mr-2">
                        <i class="fas fa-circle text-<?= $index === 0 ? 'primary' : ($index === 1 ? 'success' : ($index === 2 ? 'info' : 'warning')) ?>"></i> <?= $type ?>
                    </span>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($reportType === 'penalties'): ?>
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card border-left-danger shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                            Total Denda</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($penaltySummary['total_penalties']) ? $penaltySummary['total_penalties'] : 0 ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Denda Dibayar</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($penaltySummary['paid_penalty_amount']) ? formatCurrency($penaltySummary['paid_penalty_amount']) : formatCurrency(0) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Denda Belum Dibayar</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= isset($penaltySummary['unpaid_penalty_amount']) ? formatCurrency($penaltySummary['unpaid_penalty_amount']) : formatCurrency(0) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Jenis Denda</th>
                                <th>Jumlah</th>
                                <th>Total Jumlah</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($penaltyData)): ?>
                            <tr>
                                <td colspan="4" class="text-center">Tidak ada data denda untuk periode yang dipilih</td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($penaltyData as $penalty): ?>
                                <tr>
                                    <td><?= $penalty['jenis_denda'] ?></td>
                                    <td><?= $penalty['penalty_count'] ?></td>
                                    <td><?= formatCurrency($penalty['total_amount']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $penalty['status'] === 'Lunas' ? 'success' : 'danger' ?>">
                                            <?= $penalty['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($reportType === 'occupancy'): ?>
    // Grafik Tingkat Hunian
    var ctx = document.getElementById("reportChart").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($dates ?? []) ?>,
            datasets: [{
                label: "Tingkat Hunian (%)",
                lineTension: 0.3,
                backgroundColor: "rgba(78, 115, 223, 0.05)",
                borderColor: "rgba(78, 115, 223, 1)",
                pointRadius: 3,
                pointBackgroundColor: "rgba(78, 115, 223, 1)",
                pointBorderColor: "rgba(78, 115, 223, 1)",
                pointHoverRadius: 3,
                pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
                pointHoverBorderColor: "rgba(78, 115, 223, 1)",
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data: <?= json_encode($occupancyRates ?? []) ?>,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        callback: function(value, index, values) {
                            return value + '%';
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel + '%';
                    }
                }
            }
        }
    });
    <?php elseif ($reportType === 'revenue'): ?>
    // Grafik Pendapatan
    var ctx = document.getElementById("reportChart").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($dates ?? []) ?>,
            datasets: [{
                label: "Pendapatan",
                backgroundColor: "#4e73df",
                hoverBackgroundColor: "#2e59d9",
                borderColor: "#4e73df",
                data: <?= json_encode($revenues ?? []) ?>,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        callback: function(value, index, values) {
                            return 'Rp ' + value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': Rp ' + tooltipItem.yLabel.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            }
        }
    });
    <?php elseif ($reportType === 'room_type'): ?>
    // Grafik Tipe Kamar
    var ctx = document.getElementById("roomTypeChart").getContext('2d');
    var myPieChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($roomTypes ?? []) ?>,
            datasets: [{
                data: <?= json_encode($bookingCounts ?? []) ?>,
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e'],
                hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf', '#dda20a'],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
            }],
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
            },
            legend: {
                display: false
            },
            cutoutPercentage: 70,
        },
    });
    <?php endif; ?>
});
</script>