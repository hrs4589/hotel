<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Include database connection
global $pdo;

// Get dashboard statistics
try {
    // Get total number of rooms
    $stmt = $pdo->query("SELECT COUNT(*) AS total FROM kamar");
    $totalRooms = $stmt->fetch()['total'];
    
    // Get available rooms
    $stmt = $pdo->query("SELECT COUNT(*) AS available FROM kamar WHERE status = 'Tersedia'");
    $availableRooms = $stmt->fetch()['available'];
    
    // Get current bookings (Check-In status)
    $stmt = $pdo->query("SELECT COUNT(*) AS current FROM pemesanan WHERE status = 'Check-In'");
    $currentBookings = $stmt->fetch()['current'];
    
    // Get upcoming bookings (Confirmed status)
    $stmt = $pdo->query("SELECT COUNT(*) AS upcoming FROM pemesanan WHERE status = 'Dikonfirmasi'");
    $upcomingBookings = $stmt->fetch()['upcoming'];
    
    // Get recent bookings
    $stmt = $pdo->query("
        SELECT p.*, t.nama_lengkap, k.nomor_kamar, k.tipe 
        FROM pemesanan p
        JOIN tamu t ON p.id_tamu = t.id_tamu
        JOIN kamar k ON p.id_kamar = k.id_kamar
        ORDER BY p.id_pemesanan DESC
        LIMIT 5
    ");
    $recentBookings = $stmt->fetchAll();
    
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit;
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <?php if (hasRole('Manajer')): ?>
        <a href="index.php?page=reports" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="bi bi-download fa-sm text-white-50"></i> Buat Laporan
        </a>
        <?php endif; ?>
    </div>

    <!-- Welcome Message -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-left-primary shadow h-100 welcome-card">
                <div class="card-body position-relative">
                    <div class="row no-gutters align-items-center">
                        <div class="col-auto mr-4">
                            <div class="icon-circle bg-gradient-primary pulse-animation">
                                <i class="bi bi-building-check text-white"></i>
                            </div>
                        </div>
                        <div class="col">
                            <h5 class="card-title font-weight-bold text-primary">Selamat Datang di Sistem Manajemen Hotel</h5>
                            <div class="card-text">
                                <p class="mb-1">Hari ini <span class="fw-bold"><?= date('d F Y') ?></span>. 
                                <span class="badge bg-success text-white">Sistem Online <i class="bi bi-check-circle-fill"></i></span></p>
                                <div class="mt-2 quick-links">
                                    <?php if (hasRole('Resepsionis')): ?>
                                        <a href="index.php?page=pemesanan" class="btn btn-sm btn-outline-primary mr-2 rounded-pill">
                                            <i class="bi bi-calendar-plus"></i> Reservasi Baru
                                        </a>
                                        <a href="index.php?page=kamar" class="btn btn-sm btn-outline-success mr-2 rounded-pill">
                                            <i class="bi bi-door-open"></i> Kamar
                                        </a>
                                        <a href="index.php?page=tamu" class="btn btn-sm btn-outline-info rounded-pill">
                                            <i class="bi bi-people"></i> Daftar Tamu
                                        </a>
                                    <?php endif; ?>
                                    <?php if (hasRole('Admin')): ?>
                                        <a href="index.php?page=users" class="btn btn-sm btn-outline-secondary rounded-pill">
                                            <i class="bi bi-person-gear"></i> Manajemen User
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="welcome-decoration">
                            <i class="bi bi-stars text-light"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Total Rooms Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2 rounded-lg stat-card">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Kamar</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800 counter"><?= $totalRooms ?></div>
                            <div class="mt-2 text-xs text-muted">Kapasitas hotel</div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-primary-soft">
                                <i class="bi bi-building-fill text-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress progress-sm mt-3">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Available Rooms Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2 rounded-lg stat-card">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Kamar Tersedia</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800 counter"><?= $availableRooms ?></div>
                            <div class="mt-2 text-xs text-muted">Siap ditempati</div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-success-soft">
                                <i class="bi bi-door-open-fill text-success"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress progress-sm mt-3">
                        <div class="progress-bar bg-success" role="progressbar" 
                            style="width: <?= ($availableRooms / $totalRooms) * 100 ?>%" 
                            aria-valuenow="<?= ($availableRooms / $totalRooms) * 100 ?>" 
                            aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Current Bookings Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2 rounded-lg stat-card">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Tamu Saat Ini</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800 counter"><?= $currentBookings ?></div>
                            <div class="mt-2 text-xs text-muted">Check-in terkini</div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-info-soft"> 
                                <i class="bi bi-people-fill text-info"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress progress-sm mt-3">
                        <div class="progress-bar bg-info" role="progressbar" 
                            style="width: <?= ($currentBookings / $totalRooms) * 100 ?>%" 
                            aria-valuenow="<?= ($currentBookings / $totalRooms) * 100 ?>" 
                            aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Upcoming Bookings Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2 rounded-lg stat-card">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Reservasi Mendatang</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800 counter"><?= $upcomingBookings ?></div>
                            <div class="mt-2 text-xs text-muted">Status terkonfirmasi</div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-warning-soft">
                                <i class="bi bi-calendar-check-fill text-warning"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress progress-sm mt-3">
                        <div class="progress-bar bg-warning" role="progressbar" 
                            style="width: <?= ($upcomingBookings / max(1, $totalRooms)) * 100 ?>%" 
                            aria-valuenow="<?= ($upcomingBookings / max(1, $totalRooms)) * 100 ?>" 
                            aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Recent Bookings -->
        <div class="col-lg-8">
            <div class="card shadow mb-4 rounded-lg">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between bg-gradient-primary-to-secondary text-white">
                    <h6 class="m-0 font-weight-bold">Reservasi Terbaru</h6>
                    <?php if (hasRole('Resepsionis')): ?>
                    <a href="index.php?page=pemesanan" class="btn btn-sm btn-light rounded-pill">
                        <i class="bi bi-list"></i> Lihat Semua
                    </a>
                    <?php endif; ?>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover booking-table mb-0" width="100%" cellspacing="0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="pl-4">ID</th>
                                    <th>Nama Tamu</th>
                                    <th>Kamar</th>
                                    <th>Check-In</th>
                                    <th>Check-Out</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentBookings)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <div class="empty-state">
                                            <i class="bi bi-calendar-x display-4 text-muted"></i>
                                            <p class="mt-2 mb-0">Belum ada data pemesanan</p>
                                        </div>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($recentBookings as $booking): ?>
                                    <tr>
                                        <td class="pl-4 font-weight-bold">#<?= $booking['id_pemesanan'] ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar avatar-sm bg-primary rounded-circle mr-2 text-white">
                                                    <?= strtoupper(substr($booking['nama_lengkap'], 0, 1)) ?>
                                                </div>
                                                <span class="font-weight-medium"><?= $booking['nama_lengkap'] ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="icon-square bg-light mr-2">
                                                    <i class="bi bi-door-closed text-dark"></i>
                                                </div>
                                                <div>
                                                    <span class="font-weight-medium">Kamar <?= $booking['nomor_kamar'] ?></span>
                                                    <span class="text-muted d-block small"><?= $booking['tipe'] ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <i class="bi bi-box-arrow-in-right text-success mr-1"></i>
                                            <?= formatDate($booking['tanggal_checkin']) ?>
                                        </td>
                                        <td>
                                            <i class="bi bi-box-arrow-right text-danger mr-1"></i>
                                            <?= formatDate($booking['tanggal_checkout']) ?>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge badge-<?= strtolower(str_replace('-', '', $booking['status'])) ?> rounded-pill px-3 py-2">
                                                <?= $booking['status'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Room Status -->
        <div class="col-lg-4">
            <div class="card shadow mb-4 rounded-lg">
                <div class="card-header py-3 bg-gradient-primary-to-secondary text-white">
                    <h6 class="m-0 font-weight-bold">Status Kamar</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="roomStatusChart"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <div class="d-flex justify-content-center">
                            <div class="px-3 status-indicator">
                                <i class="bi bi-circle-fill text-success"></i> 
                                <span class="ml-2">Tersedia</span>
                                <div class="small text-muted"><?= $availableRooms ?> kamar</div>
                            </div>
                            <div class="px-3 status-indicator">
                                <i class="bi bi-circle-fill text-warning"></i> 
                                <span class="ml-2">Terisi</span>
                                <div class="small text-muted"><?= $currentBookings ?> kamar</div>
                            </div>
                            <div class="px-3 status-indicator">
                                <i class="bi bi-circle-fill text-danger"></i> 
                                <span class="ml-2">Maintenance</span>
                                <div class="small text-muted"><?= $totalRooms - $availableRooms - $currentBookings ?> kamar</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (hasRole('Manajer')): ?>
    <!-- Content Row -->
    <div class="row">
        <!-- Occupancy Rate -->
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4 rounded-lg">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Tingkat Hunian (7 Hari Terakhir)</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="occupancyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<!-- /.container-fluid -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Animasi counter untuk angka
    $('.counter').each(function() {
        const $this = $(this);
        const countTo = parseInt($this.text(), 10);
        
        $({ countNum: 0 }).animate({
            countNum: countTo
        }, {
            duration: 1000,
            easing: 'swing',
            step: function() {
                $this.text(Math.floor(this.countNum));
            },
            complete: function() {
                $this.text(this.countNum);
            }
        });
    });

    // Grafik Status Kamar
    var ctx = document.getElementById("roomStatusChart").getContext('2d');
    var roomStatusChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ["Tersedia", "Terisi", "Maintenance"],
            datasets: [{
                data: [
                    <?= $availableRooms ?>, 
                    <?= $currentBookings ?>, 
                    <?= $totalRooms - $availableRooms - $currentBookings ?>
                ],
                backgroundColor: ['#1cc88a', '#f6c23e', '#e74a3b'],
                hoverBackgroundColor: ['#17a673', '#dda20a', '#be2617'],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
            }],
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
            },
            legend: {
                display: false
            },
            cutoutPercentage: 70,
        },
    });
    
    <?php if (hasRole('Manajer')): ?>
    // Grafik Tingkat Hunian (khusus untuk manajer)
    var occupancyCtx = document.getElementById("occupancyChart").getContext('2d');
    var occupancyChart = new Chart(occupancyCtx, {
        type: 'line',
        data: {
            labels: ["7 hari lalu", "6 hari lalu", "5 hari lalu", "4 hari lalu", "3 hari lalu", "2 hari lalu", "Hari ini"],
            datasets: [{
                label: "Tingkat Hunian",
                lineTension: 0.3,
                backgroundColor: "rgba(78, 115, 223, 0.05)",
                borderColor: "rgba(78, 115, 223, 1)",
                pointRadius: 3,
                pointBackgroundColor: "rgba(78, 115, 223, 1)",
                pointBorderColor: "rgba(78, 115, 223, 1)",
                pointHoverRadius: 3,
                pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
                pointHoverBorderColor: "rgba(78, 115, 223, 1)",
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data: [65, 70, 80, 75, 85, 90, 78],
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        callback: function(value, index, values) {
                            return value + '%';
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel + '%';
                    }
                }
            }
        }
    });
    <?php endif; ?>
});
</script>