<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user has permission to access this page
if (!hasRole(['Resepsionis'])) {
    echo '<div class="container-fluid"><div class="alert alert-danger">You do not have permission to access this page.</div></div>';
    exit;
}

// Process form submissions
$success = $error = '';

// Process add/edit booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // Common form data
    $id_tamu = isset($_POST['id_tamu']) ? (int)$_POST['id_tamu'] : 0;
    $id_kamar = isset($_POST['id_kamar']) ? (int)$_POST['id_kamar'] : 0;
    $tanggal_checkin = sanitize($_POST['tanggal_checkin']);
    $tanggal_checkout = sanitize($_POST['tanggal_checkout']);
    $jumlah_tamu = isset($_POST['jumlah_tamu']) ? (int)$_POST['jumlah_tamu'] : 0;
    $total_harga = isset($_POST['total_harga']) ? (float)$_POST['total_harga'] : 0;
    $status = sanitize($_POST['status']);
    $metode_pembayaran = isset($_POST['metode_pembayaran']) ? sanitize($_POST['metode_pembayaran']) : null;
    
    // Validate form data
    if ($id_tamu <= 0 || $id_kamar <= 0 || empty($tanggal_checkin) || empty($tanggal_checkout) || $jumlah_tamu <= 0 || $total_harga <= 0) {
        $error = 'Semua data harus diisi dengan lengkap dan valid';
    } else {
        try {
            // Check room availability for the specified dates
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM pemesanan 
                WHERE id_kamar = ? 
                AND (
                    (tanggal_checkin BETWEEN ? AND ?) 
                    OR (tanggal_checkout BETWEEN ? AND ?)
                    OR (? BETWEEN tanggal_checkin AND tanggal_checkout)
                )
                AND status IN ('Menunggu', 'Dikonfirmasi', 'Check-In')
                AND id_pemesanan != ?
            ");
            $id_pemesanan = isset($_POST['id_pemesanan']) ? (int)$_POST['id_pemesanan'] : 0;
            $stmt->execute([$id_kamar, $tanggal_checkin, $tanggal_checkout, $tanggal_checkin, $tanggal_checkout, $tanggal_checkin, $id_pemesanan]);
            $isRoomBooked = $stmt->fetchColumn() > 0;
            
            if ($isRoomBooked && ($action === 'add' || ($action === 'edit' && $status !== 'Dibatalkan'))) {
                $error = 'Kamar sudah dipesan untuk tanggal yang dipilih';
            } else {
                // Handle payment proof upload
                $bukti_pembayaran = '';
                if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $bukti_pembayaran = uploadFile($_FILES['bukti_pembayaran'], 'payments');
                    if ($bukti_pembayaran === false) {
                        $error = 'Gagal mengunggah bukti pembayaran. Periksa tipe dan ukuran file.';
                    }
                }
                
                if (empty($error)) {
                    if ($action === 'add') {
                        // Insert new booking
                        $stmt = $pdo->prepare("
                            INSERT INTO pemesanan (id_tamu, id_kamar, tanggal_checkin, tanggal_checkout, jumlah_tamu, total_harga, status, metode_pembayaran, bukti_pembayaran)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$id_tamu, $id_kamar, $tanggal_checkin, $tanggal_checkout, $jumlah_tamu, $total_harga, $status, $metode_pembayaran, $bukti_pembayaran]);
                        
                        // Update room status if booking confirmed
                        if ($status === 'Dikonfirmasi' || $status === 'Check-In') {
                            $stmt = $pdo->prepare("UPDATE kamar SET status = 'Dipesan' WHERE id_kamar = ?");
                            $stmt->execute([$id_kamar]);
                        }
                        
                        $success = 'Pemesanan berhasil ditambahkan';
                    } elseif ($action === 'edit' && isset($_POST['id_pemesanan'])) {
                        $id_pemesanan = (int)$_POST['id_pemesanan'];
                        
                        // Get current booking data
                        $stmt = $pdo->prepare("SELECT * FROM pemesanan WHERE id_pemesanan = ?");
                        $stmt->execute([$id_pemesanan]);
                        $currentBooking = $stmt->fetch();
                        
                        if (!$currentBooking) {
                            $error = 'Pemesanan tidak ditemukan';
                        } else {
                            // If no new payment proof uploaded, keep the existing one
                            if (empty($bukti_pembayaran)) {
                                $bukti_pembayaran = $currentBooking['bukti_pembayaran'];
                            }
                            
                            // Update booking data
                            $stmt = $pdo->prepare("
                                UPDATE pemesanan 
                                SET id_tamu = ?, id_kamar = ?, tanggal_checkin = ?, tanggal_checkout = ?, 
                                    jumlah_tamu = ?, total_harga = ?, status = ?, metode_pembayaran = ?, bukti_pembayaran = ?
                                WHERE id_pemesanan = ?
                            ");
                            $stmt->execute([$id_tamu, $id_kamar, $tanggal_checkin, $tanggal_checkout, $jumlah_tamu, $total_harga, $status, $metode_pembayaran, $bukti_pembayaran, $id_pemesanan]);
                            
                            // Update room status based on booking status
                            if ($status === 'Dikonfirmasi' || $status === 'Check-In') {
                                $stmt = $pdo->prepare("UPDATE kamar SET status = 'Dipesan' WHERE id_kamar = ?");
                                $stmt->execute([$id_kamar]);
                            } elseif ($status === 'Check-Out') {
                                // Change room status to Maintenance when booking is checked out
                                $stmt = $pdo->prepare("UPDATE kamar SET status = 'Maintenance' WHERE id_kamar = ?");
                                $stmt->execute([$id_kamar]);
                            } elseif ($status === 'Dibatalkan') {
                                $stmt = $pdo->prepare("UPDATE kamar SET status = 'Tersedia' WHERE id_kamar = ?");
                                $stmt->execute([$id_kamar]);
                            }
                            
                            $success = 'Pemesanan berhasil diperbarui';
                        }
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Process delete booking
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_pemesanan = (int)$_GET['id'];
    
    try {
        // Get booking data
        $stmt = $pdo->prepare("SELECT * FROM pemesanan WHERE id_pemesanan = ?");
        $stmt->execute([$id_pemesanan]);
        $booking = $stmt->fetch();
        
        if (!$booking) {
            $error = 'Pemesanan tidak ditemukan';
        } else {
            // Check if booking has penalties
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM denda WHERE id_pemesanan = ?");
            $stmt->execute([$id_pemesanan]);
            if ($stmt->fetchColumn() > 0) {
                $error = 'Pemesanan ini tidak dapat dihapus karena memiliki denda terkait';
            } else {
                // Delete the booking
                $stmt = $pdo->prepare("DELETE FROM pemesanan WHERE id_pemesanan = ?");
                $stmt->execute([$id_pemesanan]);
                
                // Update room status to Maintenance if the booking was checked out
                if ($booking['status'] === 'Check-Out') {
                    $stmt = $pdo->prepare("UPDATE kamar SET status = 'Maintenance' WHERE id_kamar = ?");
                    $stmt->execute([$booking['id_kamar']]);
                } else {
                    // For other statuses, set room to available
                    $stmt = $pdo->prepare("UPDATE kamar SET status = 'Tersedia' WHERE id_kamar = ?");
                    $stmt->execute([$booking['id_kamar']]);
                }
                
                $success = 'Pemesanan berhasil dihapus';
            }
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Get all bookings with guest and room details
try {
    $stmt = $pdo->query("
        SELECT p.*, t.nama_lengkap, k.nomor_kamar, k.tipe, k.foto_kamar, k.fasilitas 
        FROM pemesanan p
        JOIN tamu t ON p.id_tamu = t.id_tamu
        JOIN kamar k ON p.id_kamar = k.id_kamar
        ORDER BY p.tanggal_checkin DESC
    ");
    $bookings = $stmt->fetchAll();
    
    // Get all guests for the dropdown
    $stmt = $pdo->query("SELECT id_tamu, nama_lengkap, no_ktp FROM tamu ORDER BY nama_lengkap");
    $guests = $stmt->fetchAll();
    
    // Get all rooms for the dropdown
    $stmt = $pdo->query("SELECT id_kamar, nomor_kamar, tipe, harga_per_malam, status FROM kamar ORDER BY nomor_kamar");
    $rooms = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $bookings = $guests = $rooms = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Booking Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBookingModal">
            <i class="fas fa-plus"></i> Add New Booking
        </button>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Booking List -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Bookings</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Guest</th>
                            <th>Room</th>
                            <th>Check-In</th>
                            <th>Check-Out</th>
                            <th>Guests</th>
                            <th>Total Price</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($bookings)): ?>
                        <tr>
                            <td colspan="10" class="text-center">No bookings found</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?= $booking['id_pemesanan'] ?></td>
                                <td><?= $booking['nama_lengkap'] ?></td>
                                <td><?= $booking['nomor_kamar'] ?> (<?= $booking['tipe'] ?>)</td>
                                <td><?= formatDate($booking['tanggal_checkin']) ?></td>
                                <td><?= formatDate($booking['tanggal_checkout']) ?></td>
                                <td><?= $booking['jumlah_tamu'] ?></td>
                                <td><?= formatCurrency($booking['total_harga']) ?></td>
                                <td>
                                    <span class="badge transaction-status <?= strtolower(str_replace(['-', ' '], '', $booking['status'])) ?>">
                                        <?= $booking['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?= $booking['metode_pembayaran'] ?: 'N/A' ?>
                                    <?php if ($booking['bukti_pembayaran']): ?>
                                        <a href="#" class="view-payment" data-bs-toggle="modal" data-bs-target="#viewPaymentModal" data-src="uploads/payments/<?= $booking['bukti_pembayaran'] ?>">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info btn-detail" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#detailBookingModal"
                                            data-id="<?= $booking['id_pemesanan'] ?>"
                                            data-tamu="<?= $booking['nama_lengkap'] ?>"
                                            data-kamar="<?= $booking['nomor_kamar'] ?> (<?= $booking['tipe'] ?>)"
                                            data-checkin="<?= formatDate($booking['tanggal_checkin']) ?>"
                                            data-checkout="<?= formatDate($booking['tanggal_checkout']) ?>"
                                            data-jumlah="<?= $booking['jumlah_tamu'] ?>"
                                            data-total="<?= formatCurrency($booking['total_harga']) ?>"
                                            data-status="<?= $booking['status'] ?>"
                                            data-metode="<?= $booking['metode_pembayaran'] ?>"
                                            data-bukti="<?= $booking['bukti_pembayaran'] ?>"
                                            data-foto-kamar="<?= $booking['foto_kamar'] ?>"
                                            data-fasilitas="<?= $booking['fasilitas'] ?>">
                                        <i class="fas fa-info-circle"></i> 
                                    </button>
                                    <button type="button" class="btn btn-sm btn-primary btn-edit" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editBookingModal"
                                            data-id="<?= $booking['id_pemesanan'] ?>"
                                            data-tamu="<?= $booking['id_tamu'] ?>"
                                            data-kamar="<?= $booking['id_kamar'] ?>"
                                            data-checkin="<?= $booking['tanggal_checkin'] ?>"
                                            data-checkout="<?= $booking['tanggal_checkout'] ?>"
                                            data-jumlah="<?= $booking['jumlah_tamu'] ?>"
                                            data-total="<?= $booking['total_harga'] ?>"
                                            data-status="<?= $booking['status'] ?>"
                                            data-metode="<?= $booking['metode_pembayaran'] ?>"
                                            data-bukti="<?= $booking['bukti_pembayaran'] ?>">
                                        <i class="fas fa-edit"></i> 
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<!-- Add Booking Modal -->
<div class="modal fade" id="addBookingModal" tabindex="-1" aria-labelledby="addBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBookingModalLabel">Add New Booking</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="id_tamu" class="form-label">Guest</label>
                            <select class="form-control" id="id_tamu" name="id_tamu" required>
                                <option value="">Select Guest</option>
                                <?php foreach ($guests as $guest): ?>
                                <option value="<?= $guest['id_tamu'] ?>"><?= $guest['nama_lengkap'] ?> (<?= $guest['no_ktp'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="id_kamar" class="form-label">Room</label>
                            <select class="form-control" id="id_kamar" name="id_kamar" required>
                                <option value="">Select Room</option>
                                <?php foreach ($rooms as $room): ?>
                                <option value="<?= $room['id_kamar'] ?>" data-price="<?= $room['harga_per_malam'] ?>" <?= $room['status'] !== 'Tersedia' ? 'disabled' : '' ?>>
                                    <?= $room['nomor_kamar'] ?> (<?= $room['tipe'] ?>) - <?= formatCurrency($room['harga_per_malam']) ?>/night
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="tanggal_checkin" class="form-label">Check-In Date</label>
                            <input type="date" class="form-control" id="tanggal_checkin" name="tanggal_checkin" required min="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="tanggal_checkout" class="form-label">Check-Out Date</label>
                            <input type="date" class="form-control" id="tanggal_checkout" name="tanggal_checkout" required min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="jumlah_tamu" class="form-label">Number of Guests</label>
                            <input type="number" class="form-control" id="jumlah_tamu" name="jumlah_tamu" min="1" value="1" required>
                        </div>
                        <div class="col-md-4">
                            <label for="room_price" class="form-label">Price per Night</label>
                            <input type="number" class="form-control" id="room_price" name="room_price" step="0.01" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="total_harga" class="form-label">Total Price</label>
                            <input type="number" class="form-control" id="total_harga" name="total_harga" step="0.01" required readonly>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-control" id="status" name="status" required>
                                <?php foreach (getBookingStatuses() as $status): ?>
                                <option value="<?= $status ?>"><?= $status ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="metode_pembayaran" class="form-label">Payment Method</label>
                            <select class="form-control" id="metode_pembayaran" name="metode_pembayaran">
                                <option value="">Select Payment Method</option>
                                <?php foreach (getPaymentMethods() as $method): ?>
                                <option value="<?= $method ?>"><?= $method ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3" id="payment_proof_container">
                        <label for="bukti_pembayaran" class="form-label">Payment Proof</label>
                        <input type="file" class="form-control" id="bukti_pembayaran" name="bukti_pembayaran" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Booking Modal -->
<div class="modal fade" id="editBookingModal" tabindex="-1" aria-labelledby="editBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editBookingModalLabel">Edit Booking</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id_pemesanan" id="edit_id_pemesanan">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_id_tamu" class="form-label">Guest</label>
                            <select class="form-control" id="edit_id_tamu" name="id_tamu" required>
                                <option value="">Select Guest</option>
                                <?php foreach ($guests as $guest): ?>
                                <option value="<?= $guest['id_tamu'] ?>"><?= $guest['nama_lengkap'] ?> (<?= $guest['no_ktp'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_id_kamar" class="form-label">Room</label>
                            <select class="form-control" id="edit_id_kamar" name="id_kamar" required>
                                <option value="">Select Room</option>
                                <?php foreach ($rooms as $room): ?>
                                <option value="<?= $room['id_kamar'] ?>" data-price="<?= $room['harga_per_malam'] ?>">
                                    <?= $room['nomor_kamar'] ?> (<?= $room['tipe'] ?>) - <?= formatCurrency($room['harga_per_malam']) ?>/night
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_tanggal_checkin" class="form-label">Check-In Date</label>
                            <input type="date" class="form-control" id="edit_tanggal_checkin" name="tanggal_checkin" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_tanggal_checkout" class="form-label">Check-Out Date</label>
                            <input type="date" class="form-control" id="edit_tanggal_checkout" name="tanggal_checkout" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="edit_jumlah_tamu" class="form-label">Number of Guests</label>
                            <input type="number" class="form-control" id="edit_jumlah_tamu" name="jumlah_tamu" min="1" required>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_room_price" class="form-label">Price per Night</label>
                            <input type="number" class="form-control" id="edit_room_price" name="room_price" step="0.01" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_total_harga" class="form-label">Total Price</label>
                            <input type="number" class="form-control" id="edit_total_harga" name="total_harga" step="0.01" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-control" id="edit_status" name="status" required>
                                <?php foreach (getBookingStatuses() as $status): ?>
                                <option value="<?= $status ?>"><?= $status ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_metode_pembayaran" class="form-label">Payment Method</label>
                            <select class="form-control" id="edit_metode_pembayaran" name="metode_pembayaran">
                                <option value="">Select Payment Method</option>
                                <?php foreach (getPaymentMethods() as $method): ?>
                                <option value="<?= $method ?>"><?= $method ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3" id="edit_payment_proof_container">
                        <label for="edit_bukti_pembayaran" class="form-label">Payment Proof</label>
                        <input type="file" class="form-control" id="edit_bukti_pembayaran" name="bukti_pembayaran" accept="image/*">
                        <small class="form-text text-muted">Leave empty to keep current file</small>
                        <div id="bukti_pembayaran_preview" class="mt-2">
                            <img id="bukti_preview" class="img-thumbnail" style="max-width: 200px; display: none;">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Detail Booking Modal -->
<div class="modal fade" id="detailBookingModal" tabindex="-1" aria-labelledby="detailBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title" id="detailBookingModalLabel">Detail Pemesanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-hotel mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Informasi Tamu</h5>
                                <div class="mb-2">
                                    <strong>Nama Tamu:</strong> <span id="detail_tamu"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Jumlah Tamu:</strong> <span id="detail_jumlah"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Total Harga:</strong> <span id="detail_total"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Status:</strong> <span id="detail_status" class="badge transaction-status"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Metode Pembayaran:</strong> <span id="detail_metode"></span>
                                </div>
                            </div>
                        </div>
                        <div id="detail_bukti_container" class="card-hotel mb-3 d-none">
                            <div class="card-body">
                                <h5 class="card-title">Bukti Pembayaran</h5>
                                <div class="text-center">
                                    <img src="" id="detail_bukti" class="img-fluid" alt="Bukti Pembayaran" style="max-height: 150px;">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-hotel mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Informasi Kamar</h5>
                                <div class="mb-2">
                                    <strong>Kamar:</strong> <span id="detail_kamar"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Check-in:</strong> <span id="detail_checkin"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Check-out:</strong> <span id="detail_checkout"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Fasilitas:</strong> <span id="detail_fasilitas"></span>
                                </div>
                            </div>
                        </div>
                        <div id="detail_foto_kamar_container" class="card-hotel mb-3 d-none">
                            <div class="card-body">
                                <h5 class="card-title">Foto Kamar</h5>
                                <div class="text-center">
                                    <img src="" id="detail_foto_kamar" class="img-fluid" alt="Foto Kamar" style="max-height: 150px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="#" id="detail_delete_link" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Hapus Pemesanan
                </a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<!-- View Payment Modal -->
<div class="modal fade" id="viewPaymentModal" tabindex="-1" aria-labelledby="viewPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewPaymentModalLabel">Bukti Pembayaran</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <img id="payment_image" src="" class="img-fluid" alt="Bukti Pembayaran">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Calculate total price based on room price and duration
    function calculateTotalPrice(checkinInput, checkoutInput, priceInput, totalInput) {
        if (checkinInput.value && checkoutInput.value && priceInput.value) {
            const checkin = new Date(checkinInput.value);
            const checkout = new Date(checkoutInput.value);
            const pricePerNight = parseFloat(priceInput.value);
            
            // Check if dates are valid
            if (checkout <= checkin) {
                alert('Checkout date must be after checkin date');
                checkoutInput.value = '';
                totalInput.value = '';
                return;
            }
            
            // Calculate number of nights
            const timeDiff = checkout.getTime() - checkin.getTime();
            const nights = Math.ceil(timeDiff / (1000 * 3600 * 24));
            
            // Calculate total price
            const totalPrice = nights * pricePerNight;
            totalInput.value = totalPrice.toFixed(2);
        }
    }

    // Add Booking Modal
    const checkinInput = document.getElementById('tanggal_checkin');
    const checkoutInput = document.getElementById('tanggal_checkout');
    const roomPriceInput = document.getElementById('room_price');
    const totalPriceInput = document.getElementById('total_harga');
    const roomSelect = document.getElementById('id_kamar');
    
    if (roomSelect) {
        roomSelect.addEventListener('change', function() {
            if (this.value) {
                const selectedOption = this.options[this.selectedIndex];
                const price = selectedOption.dataset.price;
                if (roomPriceInput) {
                    roomPriceInput.value = price;
                    calculateTotalPrice(checkinInput, checkoutInput, roomPriceInput, totalPriceInput);
                }
            } else {
                roomPriceInput.value = '';
                totalPriceInput.value = '';
            }
        });
    }
    
    if (checkinInput && checkoutInput) {
        checkinInput.addEventListener('change', function() {
            calculateTotalPrice(checkinInput, checkoutInput, roomPriceInput, totalPriceInput);
        });
        
        checkoutInput.addEventListener('change', function() {
            calculateTotalPrice(checkinInput, checkoutInput, roomPriceInput, totalPriceInput);
        });
    }
    
    // Edit Booking Modal
    const editCheckinInput = document.getElementById('edit_tanggal_checkin');
    const editCheckoutInput = document.getElementById('edit_tanggal_checkout');
    const editRoomPriceInput = document.getElementById('edit_room_price');
    const editTotalPriceInput = document.getElementById('edit_total_harga');
    const editRoomSelect = document.getElementById('edit_id_kamar');
    
    if (editRoomSelect) {
        editRoomSelect.addEventListener('change', function() {
            if (this.value) {
                const selectedOption = this.options[this.selectedIndex];
                const price = selectedOption.dataset.price;
                if (editRoomPriceInput) {
                    editRoomPriceInput.value = price;
                    calculateTotalPrice(editCheckinInput, editCheckoutInput, editRoomPriceInput, editTotalPriceInput);
                }
            } else {
                editRoomPriceInput.value = '';
                editTotalPriceInput.value = '';
            }
        });
    }
    
    if (editCheckinInput && editCheckoutInput) {
        editCheckinInput.addEventListener('change', function() {
            calculateTotalPrice(editCheckinInput, editCheckoutInput, editRoomPriceInput, editTotalPriceInput);
        });
        
        editCheckoutInput.addEventListener('change', function() {
            calculateTotalPrice(editCheckinInput, editCheckoutInput, editRoomPriceInput, editTotalPriceInput);
        });
    }

    // Handle edit booking button clicks
    const editButtons = document.querySelectorAll('.btn-edit');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get booking data from button attributes
            const bookingId = this.dataset.id;
            const tamuId = this.dataset.tamu;
            const kamarId = this.dataset.kamar;
            const checkin = this.dataset.checkin;
            const checkout = this.dataset.checkout;
            const jumlahTamu = this.dataset.jumlah;
            const totalHarga = this.dataset.total;
            const status = this.dataset.status;
            const metode = this.dataset.metode;
            const bukti = this.dataset.bukti;
            
            // Fill form fields with booking data
            document.getElementById('edit_id_pemesanan').value = bookingId;
            document.getElementById('edit_id_tamu').value = tamuId;
            document.getElementById('edit_id_kamar').value = kamarId;
            document.getElementById('edit_tanggal_checkin').value = checkin;
            document.getElementById('edit_tanggal_checkout').value = checkout;
            document.getElementById('edit_jumlah_tamu').value = jumlahTamu;
            document.getElementById('edit_total_harga').value = totalHarga;
            document.getElementById('edit_status').value = status;
            document.getElementById('edit_metode_pembayaran').value = metode || '';
            
            // Show payment proof preview if exists
            const buktiPreview = document.getElementById('bukti_preview');
            if (bukti) {
                buktiPreview.src = 'uploads/payments/' + bukti;
                buktiPreview.style.display = 'block';
            } else {
                buktiPreview.style.display = 'none';
            }
            
            // Set room price from selected room
            const selectedRoom = document.getElementById('edit_id_kamar').options[document.getElementById('edit_id_kamar').selectedIndex];
            if (selectedRoom && selectedRoom.dataset.price) {
                document.getElementById('edit_room_price').value = selectedRoom.dataset.price;
            }
        });
    });

    // Detail Booking Modal
    const detailButtons = document.querySelectorAll('.btn-detail');
    detailButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get booking data from button attributes
            const bookingId = this.dataset.id;
            const tamu = this.dataset.tamu;
            const kamar = this.dataset.kamar;
            const checkin = this.dataset.checkin;
            const checkout = this.dataset.checkout;
            const jumlahTamu = this.dataset.jumlah;
            const totalHarga = this.dataset.total;
            const status = this.dataset.status;
            const metode = this.dataset.metode || 'Tidak ada';
            const bukti = this.dataset.bukti;
            const fotoKamar = this.dataset.fotoKamar;
            const fasilitas = this.dataset.fasilitas || 'Tidak ada informasi fasilitas';
            
            // Fill modal with booking data
            document.getElementById('detail_tamu').textContent = tamu;
            document.getElementById('detail_kamar').textContent = kamar;
            document.getElementById('detail_checkin').textContent = checkin;
            document.getElementById('detail_checkout').textContent = checkout;
            document.getElementById('detail_jumlah').textContent = jumlahTamu;
            document.getElementById('detail_total').textContent = totalHarga;
            document.getElementById('detail_metode').textContent = metode;
            document.getElementById('detail_fasilitas').textContent = fasilitas;
            
            // Set status with appropriate class
            const statusElem = document.getElementById('detail_status');
            statusElem.textContent = status;
            statusElem.className = 'badge transaction-status ' + status.toLowerCase();
            
            // Show payment proof if exists
            const buktiContainer = document.getElementById('detail_bukti_container');
            const buktiImg = document.getElementById('detail_bukti');
            if (bukti) {
                buktiImg.src = 'uploads/payments/' + bukti;
                buktiContainer.classList.remove('d-none');
            } else {
                buktiContainer.classList.add('d-none');
            }
            
            // Show room photo if exists
            const fotoKamarContainer = document.getElementById('detail_foto_kamar_container');
            const fotoKamarImg = document.getElementById('detail_foto_kamar');
            if (fotoKamar) {
                fotoKamarImg.src = 'uploads/rooms/' + fotoKamar;
                fotoKamarContainer.classList.remove('d-none');
            } else {
                fotoKamarContainer.classList.add('d-none');
            }
            
            // Set delete link
            document.getElementById('detail_delete_link').href = 'index.php?page=pemesanan&action=delete&id=' + bookingId;
            document.getElementById('detail_delete_link').onclick = function() {
                return confirm('Apakah Anda yakin ingin menghapus pemesanan ini?');
            };
        });
    });
    
    // View payment proof
    const viewPaymentLinks = document.querySelectorAll('.view-payment');
    viewPaymentLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const imageSrc = this.dataset.src;
            document.getElementById('payment_image').src = imageSrc;
        });
    });
});
</script>