<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user is logged in as guest
if (!isGuestLoggedIn()) {
    redirect('guest_login.php');
}

// Process cancel booking request
$success = $error = '';

if (isset($_POST['action']) && $_POST['action'] === 'cancel_booking') {
    $booking_id = isset($_POST['booking_id']) ? (int)$_POST['booking_id'] : 0;
    
    if ($booking_id <= 0) {
        $error = 'Invalid booking ID';
    } else {
        try {
            // Get booking details to verify it belongs to the logged-in guest
            $stmt = $pdo->prepare("
                SELECT * FROM pemesanan 
                WHERE id_pemesanan = ? AND id_tamu = ?
            ");
            $stmt->execute([$booking_id, $_SESSION['tamu_id']]);
            $booking = $stmt->fetch();
            
            if (!$booking) {
                $error = 'Booking not found or you do not have permission to cancel it';
            } elseif ($booking['status'] !== 'Menunggu' && $booking['status'] !== 'Dikonfirmasi') {
                $error = 'Only pending or confirmed bookings can be canceled';
            } else {
                // Update booking status to Dibatalkan
                $stmt = $pdo->prepare("UPDATE pemesanan SET status = 'Dibatalkan' WHERE id_pemesanan = ?");
                $stmt->execute([$booking_id]);
                
                // Update room status back to Tersedia
                $stmt = $pdo->prepare("UPDATE kamar SET status = 'Tersedia' WHERE id_kamar = ?");
                $stmt->execute([$booking['id_kamar']]);
                
                $success = 'Your booking has been successfully canceled';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get guest's bookings
try {
    // Check if viewing a specific booking
    $viewBookingId = isset($_GET['view']) ? (int)$_GET['view'] : 0;
    
    if ($viewBookingId > 0) {
        // Get specific booking details
        $stmt = $pdo->prepare("
            SELECT p.*, k.nomor_kamar, k.tipe, k.foto_kamar, k.fasilitas, k.harga_per_malam
            FROM pemesanan p
            JOIN kamar k ON p.id_kamar = k.id_kamar
            WHERE p.id_pemesanan = ? AND p.id_tamu = ?
        ");
        $stmt->execute([$viewBookingId, $_SESSION['tamu_id']]);
        $booking = $stmt->fetch();
        
        if (!$booking) {
            $error = 'Booking not found or you do not have permission to view it';
        } else {
            // Get any penalties associated with this booking
            $stmt = $pdo->prepare("
                SELECT * FROM denda
                WHERE id_pemesanan = ?
                ORDER BY id_denda DESC
            ");
            $stmt->execute([$viewBookingId]);
            $penalties = $stmt->fetchAll();
        }
    } else {
        // Get all bookings for this guest
        $stmt = $pdo->prepare("
            SELECT p.*, k.nomor_kamar, k.tipe
            FROM pemesanan p
            JOIN kamar k ON p.id_kamar = k.id_kamar
            WHERE p.id_tamu = ?
            ORDER BY p.tanggal_checkin DESC
        ");
        $stmt->execute([$_SESSION['tamu_id']]);
        $bookings = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $bookings = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $viewBookingId > 0 ? 'Booking Details' : 'My Bookings' ?></h1>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <?php if ($viewBookingId > 0 && isset($booking)): ?>
    <!-- Booking Details View -->
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Booking #<?= $booking['id_pemesanan'] ?></h6>
                    <a href="index.php?page=guest/bookings" class="btn btn-sm btn-secondary">Back to All Bookings</a>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Room Information</h5>
                            <p><strong>Room Number:</strong> <?= $booking['nomor_kamar'] ?></p>
                            <p><strong>Room Type:</strong> <?= $booking['tipe'] ?></p>
                            <p><strong>Price per Night:</strong> <?= formatCurrency($booking['harga_per_malam']) ?></p>
                            <?php if ($booking['fasilitas']): ?>
                            <p><strong>Facilities:</strong> <?= $booking['fasilitas'] ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <h5>Booking Details</h5>
                            <p><strong>Check-In Date:</strong> <?= formatDate($booking['tanggal_checkin']) ?></p>
                            <p><strong>Check-Out Date:</strong> <?= formatDate($booking['tanggal_checkout']) ?></p>
                            <p><strong>Number of Guests:</strong> <?= $booking['jumlah_tamu'] ?></p>
                            <p><strong>Total Price:</strong> <?= formatCurrency($booking['total_harga']) ?></p>
                            <p>
                                <strong>Status:</strong> 
                                <span class="badge bg-<?= strtolower(str_replace('-', '', $booking['status'])) ?>">
                                    <?= $booking['status'] ?>
                                </span>
                            </p>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Payment Information</h5>
                            <p><strong>Payment Method:</strong> <?= $booking['metode_pembayaran'] ?: 'Not specified' ?></p>
                            <?php if ($booking['bukti_pembayaran']): ?>
                            <p>
                                <strong>Payment Proof:</strong>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#viewPaymentModal">View Payment Proof</a>
                            </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if (($booking['status'] === 'Menunggu' || $booking['status'] === 'Dikonfirmasi') && strtotime($booking['tanggal_checkin']) > time()): ?>
                    <div class="mt-4">
                        <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this booking?');">
                            <input type="hidden" name="action" value="cancel_booking">
                            <input type="hidden" name="booking_id" value="<?= $booking['id_pemesanan'] ?>">
                            <button type="submit" class="btn btn-danger">Cancel Booking</button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if (!empty($penalties)): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Penalties & Charges</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($penalties as $penalty): ?>
                                <tr>
                                    <td><?= $penalty['jenis_denda'] ?></td>
                                    <td><?= formatCurrency($penalty['jumlah']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $penalty['status'] === 'Lunas' ? 'success' : 'danger' ?>">
                                            <?= $penalty['status'] ?>
                                        </span>
                                    </td>
                                    <td><?= $penalty['deskripsi'] ?: 'N/A' ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Help & Support</h6>
                </div>
                <div class="card-body">
                    <h5>Need assistance with your booking?</h5>
                    <p>If you have any questions or need changes to your booking, please contact our front desk:</p>
                    <ul>
                        <li>Phone: +62-21-555-1234</li>
                        <li>Email: reservation@hotelname.com</li>
                        <li>WhatsApp: +62-812-3456-7890</li>
                    </ul>
                    <p>Our team is available 24/7 to assist you.</p>
                    
                    <h5 class="mt-4">Hotel Policies</h5>
                    <ul>
                        <li>Check-in time: 2:00 PM</li>
                        <li>Check-out time: 12:00 PM</li>
                        <li>Early check-in and late check-out available upon request (additional charges may apply)</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Payment Proof Modal -->
    <?php if ($booking['bukti_pembayaran']): ?>
    <div class="modal fade" id="viewPaymentModal" tabindex="-1" aria-labelledby="viewPaymentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewPaymentModalLabel">Payment Proof</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <img src="uploads/payments/<?= $booking['bukti_pembayaran'] ?>" class="img-fluid" alt="Payment Proof">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <!-- Bookings List View -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Your Bookings</h6>
        </div>
        <div class="card-body">
            <?php if (empty($bookings)): ?>
                <div class="text-center py-4">
                    <p class="text-gray-500 mb-0">You don't have any bookings yet.</p>
                    <a href="index.php?page=guest/pemesanan" class="btn btn-primary mt-3">Book a Room</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Room</th>
                                <th>Check-In</th>
                                <th>Check-Out</th>
                                <th>Total Price</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?= $booking['id_pemesanan'] ?></td>
                                <td><?= $booking['nomor_kamar'] ?> (<?= $booking['tipe'] ?>)</td>
                                <td><?= formatDate($booking['tanggal_checkin']) ?></td>
                                <td><?= formatDate($booking['tanggal_checkout']) ?></td>
                                <td><?= formatCurrency($booking['total_harga']) ?></td>
                                <td>
                                    <span class="badge bg-<?= strtolower(str_replace('-', '', $booking['status'])) ?>">
                                        <?= $booking['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="index.php?page=guest/bookings&view=<?= $booking['id_pemesanan'] ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    
                                    <?php if (($booking['status'] === 'Menunggu' || $booking['status'] === 'Dikonfirmasi') && strtotime($booking['tanggal_checkin']) > time()): ?>
                                    <button type="button" class="btn btn-sm btn-danger" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#cancelBookingModal"
                                            data-id="<?= $booking['id_pemesanan'] ?>">
                                        <i class="fas fa-times"></i> Cancel
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Cancel Booking Modal -->
    <div class="modal fade" id="cancelBookingModal" tabindex="-1" aria-labelledby="cancelBookingModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cancelBookingModalLabel">Cancel Booking</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="cancel_booking">
                        <input type="hidden" name="booking_id" id="cancel_booking_id">
                        
                        <p>Are you sure you want to cancel this booking?</p>
                        <p class="text-danger">This action cannot be undone.</p>
                        
                        <div class="alert alert-warning">
                            <strong>Cancellation Policy:</strong>
                            <ul class="mb-0">
                                <li>Free cancellation up to 48 hours before check-in</li>
                                <li>Cancellations less than 48 hours before check-in: 1 night charge</li>
                                <li>No-shows: Full booking amount will be charged</li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Confirm Cancellation</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>
<!-- /.container-fluid -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle cancel booking button clicks
    const cancelButtons = document.querySelectorAll('[data-bs-target="#cancelBookingModal"]');
    cancelButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get booking ID from button attribute
            const bookingId = this.dataset.id;
            
            // Set booking ID in the form
            document.getElementById('cancel_booking_id').value = bookingId;
        });
    });
});
</script>
