<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user is logged in as guest
if (!isGuestLoggedIn()) {
    redirect('guest_login.php');
}

// Process form submission
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    if ($action === 'update_profile') {
        $nama_lengkap = sanitize($_POST['nama_lengkap']);
        $no_hp = sanitize($_POST['no_hp']);
        $email = sanitize($_POST['email']);
        $alamat = sanitize($_POST['alamat']);
        
        if (empty($nama_lengkap) || empty($no_hp)) {
            $error = 'Name and phone number are required';
        } else {
            try {
                // Update guest data
                $stmt = $pdo->prepare("
                    UPDATE tamu 
                    SET nama_lengkap = ?, no_hp = ?, email = ?, alamat = ?
                    WHERE id_tamu = ?
                ");
                $stmt->execute([$nama_lengkap, $no_hp, $email, $alamat, $_SESSION['tamu_id']]);
                
                // Update session variable
                $_SESSION['tamu_name'] = $nama_lengkap;
                
                $success = 'Profile updated successfully';
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = 'All password fields are required';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New password and confirmation do not match';
        } else {
            try {
                // Get current password from database
                $stmt = $pdo->prepare("SELECT password FROM tamu WHERE id_tamu = ?");
                $stmt->execute([$_SESSION['tamu_id']]);
                $guest = $stmt->fetch();
                
                if (!$guest) {
                    $error = 'User not found';
                } else {
                    // Verify current password
                    if (password_verify($current_password, $guest['password']) || $current_password === $guest['password']) {
                        // Hash new password
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        
                        // Update password
                        $stmt = $pdo->prepare("UPDATE tamu SET password = ? WHERE id_tamu = ?");
                        $stmt->execute([$hashed_password, $_SESSION['tamu_id']]);
                        
                        $success = 'Password changed successfully';
                    } else {
                        $error = 'Current password is incorrect';
                    }
                }
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Get guest data
try {
    $stmt = $pdo->prepare("SELECT * FROM tamu WHERE id_tamu = ?");
    $stmt->execute([$_SESSION['tamu_id']]);
    $guest = $stmt->fetch();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $guest = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">My Profile</h1>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-6">
            <!-- Profile Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" value="<?= $guest['username'] ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="nama_lengkap" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?= $guest['nama_lengkap'] ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="no_ktp" class="form-label">ID Card Number</label>
                            <input type="text" class="form-control" id="no_ktp" value="<?= $guest['no_ktp'] ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="no_hp" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?= $guest['no_hp'] ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= $guest['email'] ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="alamat" class="form-label">Address</label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="3"><?= $guest['alamat'] ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="tanggal_daftar" class="form-label">Registration Date</label>
                            <input type="text" class="form-control" id="tanggal_daftar" value="<?= formatDate($guest['tanggal_daftar']) ?>" readonly>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6">
            <!-- Change Password -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
            </div>
            
            <!-- Account Security -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Account Security</h6>
                </div>
                <div class="card-body">
                    <p>Protect your account:</p>
                    <ul>
                        <li>Use a strong, unique password</li>
                        <li>Don't share your login details with others</li>
                        <li>Log out when using public computers</li>
                        <li>Update your contact information regularly</li>
                    </ul>
                    <p>If you notice any suspicious activity on your account, please contact us immediately.</p>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
