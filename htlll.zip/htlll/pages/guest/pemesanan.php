<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user is logged in as guest
if (!isGuestLoggedIn()) {
    redirect('login.php');
}

// Process booking form
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $id_kamar = isset($_POST['id_kamar']) ? (int)$_POST['id_kamar'] : 0;
    $tanggal_checkin = sanitize($_POST['tanggal_checkin']);
    $tanggal_checkout = sanitize($_POST['tanggal_checkout']);
    $jumlah_tamu = isset($_POST['jumlah_tamu']) ? (int)$_POST['jumlah_tamu'] : 0;
    $total_harga = isset($_POST['total_harga']) ? (float)$_POST['total_harga'] : 0;
    $metode_pembayaran = sanitize($_POST['metode_pembayaran']);
    
    // Validate form data
    if ($id_kamar <= 0 || empty($tanggal_checkin) || empty($tanggal_checkout) || $jumlah_tamu <= 0 || $total_harga <= 0 || empty($metode_pembayaran)) {
        $error = 'Harap isi semua field yang wajib diisi.';
    } else {
        try {
            // Get room capacity first
            $stmt = $pdo->prepare("SELECT kapasitas FROM kamar WHERE id_kamar = ?");
            $stmt->execute([$id_kamar]);
            $roomCapacity = $stmt->fetchColumn();
            
            // Validate guest count against room capacity
            if ($jumlah_tamu > $roomCapacity) {
                $error = 'Jumlah tamu melebihi kapasitas kamar. Maksimal tamu untuk kamar ini adalah ' . $roomCapacity;
            } else {
                // Check room availability for the specified dates
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM pemesanan 
                    WHERE id_kamar = ? 
                    AND (
                        (tanggal_checkin BETWEEN ? AND ?) 
                        OR (tanggal_checkout BETWEEN ? AND ?)
                        OR (? BETWEEN tanggal_checkin AND tanggal_checkout)
                    )
                    AND status IN ('Menunggu', 'Dikonfirmasi', 'Check-In')
                ");
                $stmt->execute([$id_kamar, $tanggal_checkin, $tanggal_checkout, $tanggal_checkin, $tanggal_checkout, $tanggal_checkin]);
                $isRoomBooked = $stmt->fetchColumn() > 0;
                
                if ($isRoomBooked) {
                    $error = 'Kamar sudah dipesan untuk tanggal yang dipilih. Silakan pilih tanggal lain atau kamar yang berbeda.';
                } else {
                    // Handle payment proof upload
                    $bukti_pembayaran = '';
                    if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] !== UPLOAD_ERR_NO_FILE) {
                        $bukti_pembayaran = uploadFile($_FILES['bukti_pembayaran'], 'payments');
                        if ($bukti_pembayaran === false) {
                            $error = 'Gagal mengunggah bukti pembayaran. Harap periksa tipe dan ukuran file.';
                        }
                    }
                    
                    if (empty($error)) {
                        // Get guest ID from session
                        $id_tamu = $_SESSION['tamu_id'];
                        
                        // Insert booking
                        $stmt = $pdo->prepare("
                            INSERT INTO pemesanan (id_tamu, id_kamar, tanggal_checkin, tanggal_checkout, jumlah_tamu, total_harga, status, metode_pembayaran, bukti_pembayaran)
                            VALUES (?, ?, ?, ?, ?, ?, 'Menunggu', ?, ?)
                        ");
                        $stmt->execute([$id_tamu, $id_kamar, $tanggal_checkin, $tanggal_checkout, $jumlah_tamu, $total_harga, $metode_pembayaran, $bukti_pembayaran]);
                        
                        $success = 'Pemesanan Anda berhasil dikirim. Staf kami akan meninjau pemesanan Anda dan memberikan konfirmasi segera.';
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get available rooms
try {
    $stmt = $pdo->query("SELECT * FROM kamar WHERE status = 'Tersedia' ORDER BY tipe, harga_per_malam");
    $availableRooms = $stmt->fetchAll();
    
    // Check if room parameter is present
    $selectedRoomId = isset($_GET['room']) ? (int)$_GET['room'] : 0;
    $selectedRoom = null;
    
    if ($selectedRoomId > 0) {
        $stmt = $pdo->prepare("SELECT * FROM kamar WHERE id_kamar = ? AND status = 'Tersedia'");
        $stmt->execute([$selectedRoomId]);
        $selectedRoom = $stmt->fetch();
    }
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $availableRooms = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Kamar</title>
    <style>
        .capacity-info {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 0.25rem;
        }
        .capacity-max {
            font-weight: bold;
            color: #28a745;
        }
        .alert-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            animation: fadeIn 0.3s;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .room-image {
            max-width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .room-details {
            margin-top: 15px;
        }
        .room-details p {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Booking Kamar</h1>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
        <p class="mt-2"><a href="index.php?page=guest/bookings" class="alert-link">Lihat pemesanan Anda</a></p>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Pemesanan</h6>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="id_kamar" class="form-label">Pilih Kamar</label>
                            <select class="form-control" id="id_kamar" name="id_kamar" required>
                                <option value="">Pilih kamar</option>
                                <?php foreach ($availableRooms as $room): ?>
                                <option value="<?= $room['id_kamar'] ?>" 
                                        data-price="<?= $room['harga_per_malam'] ?>" 
                                        data-capacity="<?= $room['kapasitas'] ?>"
                                        <?= ($selectedRoom && $selectedRoom['id_kamar'] == $room['id_kamar']) ? 'selected' : '' ?>>
                                    Kamar <?= $room['nomor_kamar'] ?> (<?= $room['tipe'] ?>) - Rp <?= number_format($room['harga_per_malam'], 0, ',', '.') ?>/malam
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="tanggal_checkin" class="form-label">Tanggal Check-In</label>
                                <input type="date" class="form-control" id="tanggal_checkin" name="tanggal_checkin" required min="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="tanggal_checkout" class="form-label">Tanggal Check-Out</label>
                                <input type="date" class="form-control" id="tanggal_checkout" name="tanggal_checkout" required min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="jumlah_tamu" class="form-label">Jumlah Tamu</label>
                                <input type="number" class="form-control" id="jumlah_tamu" name="jumlah_tamu" min="1" value="1" required>
                                <div class="capacity-info">Maksimal: <span id="maxCapacityDisplay" class="capacity-max">-</span> orang</div>
                            </div>
                            <div class="col-md-6">
                                <label for="room_price" class="form-label">Harga per Malam</label>
                                <input type="number" class="form-control" id="room_price" name="room_price" step="0.01" readonly>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="total_harga" class="form-label">Total Harga</label>
                            <input type="number" class="form-control" id="total_harga" name="total_harga" step="0.01" readonly required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="metode_pembayaran" class="form-label">Metode Pembayaran (bank : 378678)</label>
                            <select class="form-control" id="metode_pembayaran" name="metode_pembayaran" required>
                                <option value="">Pilih Metode Pembayaran</option>
                                <option value="Transfer">Transfer Bank</option>
                                <option value="Tunai">Tunai</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="payment_proof_container">
                            <label for="bukti_pembayaran" class="form-label">Bukti Pembayaran (jika menggunakan Transfer)</label>
                            <input type="file" class="form-control" id="bukti_pembayaran" name="bukti_pembayaran" accept="image/*">
                            <small class="form-text text-muted">Unggah struk atau bukti transfer.</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Pesan Sekarang</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informasi Kamar</h6>
                </div>
                <div class="card-body" id="room_details">
                    <div class="text-center py-4">
                        <p class="text-gray-500 mb-0">Pilih kamar untuk melihat detail</p>
                    </div>
                </div>
            </div>
                    
            
        </div>
        <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Kebijakan Hotel</h6>
                </div>
                <div class="card-body">
                    <h5>Check-in & Check-out</h5>
                    <ul>
                        <li>Check-in: 14:00 WIB | Check-out: 12:00 WIB</li>
                        <li>Check-in awal & check-out lambat dapat diminta, tergantung ketersediaan (biaya tambahan mungkin berlaku)</li>
                    </ul>
                    <p>Silakan informasikan waktu kedatangan Anda untuk kenyamanan bersama. Keterlambatan check-out tanpa izin dapat dikenakan biaya tambahan.</p>

                    <h5>Kebijakan Pembatalan</h5>
                    <ul>
                        <li>Pembatalan gratis hingga 24 jam sebelum waktu check-in</li>
                        <li>No-show akan dikenakan biaya penuh sesuai jumlah malam yang dipesan</li>
                    </ul>
                    <p>Kami fleksibel terhadap perubahan rencana, selama dikonfirmasi dalam waktu yang ditentukan.</p>

                    <h5>Pembayaran</h5>
                    <ul>
                        <li>Transfer ke: 378678 (bank)</li>
                        <li>Transfer: konfirmasi dalam 24 jam setelah pemesanan</li>
                        <li>Tunai: dibayarkan langsung saat check-in</li>
                    </ul>
                </div>
            </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Calculate total price
    function calculateTotalPrice() {
        const checkinInput = document.getElementById('tanggal_checkin');
        const checkoutInput = document.getElementById('tanggal_checkout');
        const priceInput = document.getElementById('room_price');
        const totalInput = document.getElementById('total_harga');
        
        if (checkinInput.value && checkoutInput.value && priceInput.value) {
            const checkin = new Date(checkinInput.value);
            const checkout = new Date(checkoutInput.value);
            const pricePerNight = parseFloat(priceInput.value);
            
            // Check if dates are valid
            if (checkout <= checkin) {
                showNotification('Tanggal checkout harus setelah tanggal checkin', 'danger');
                checkoutInput.value = '';
                totalInput.value = '';
                return;
            }
            
            // Calculate number of nights
            const timeDiff = checkout.getTime() - checkin.getTime();
            const nights = Math.ceil(timeDiff / (1000 * 3600 * 24));
            
            // Calculate total price
            const totalPrice = nights * pricePerNight;
            totalInput.value = totalPrice.toFixed(2);
        }
    }
    
    // Show notification
    function showNotification(message, type = 'danger') {
        // Remove existing notification if any
        const existingAlert = document.getElementById('notificationAlert');
        if (existingAlert) {
            existingAlert.remove();
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.id = 'notificationAlert';
        notification.className = `alert alert-${type} alert-notification`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    // Update room information
    function updateRoomInfo() {
        const roomSelect = document.getElementById('id_kamar');
        const roomDetails = document.getElementById('room_details');
        const maxCapacityDisplay = document.getElementById('maxCapacityDisplay');
        const jumlahTamuInput = document.getElementById('jumlah_tamu');
        
        if (roomSelect.value) {
            const selectedOption = roomSelect.options[roomSelect.selectedIndex];
            const roomId = roomSelect.value;
            const roomCapacity = parseInt(selectedOption.dataset.capacity);
            
            // Update max capacity display
            maxCapacityDisplay.textContent = roomCapacity;
            jumlahTamuInput.max = roomCapacity;
            
            // Get room details from available rooms data
            const roomsData = <?= json_encode($availableRooms) ?>;
            const roomData = roomsData.find(room => room.id_kamar == roomId);
            
            if (roomData) {
                // Format the price
                const formattedPrice = 'Rp ' + roomData.harga_per_malam.toLocaleString('id-ID');
                
                // Build the image HTML if photo exists
                let imageHtml = '';
                if (roomData.foto_kamar) {
                    imageHtml = `<img src="uploads/rooms/${roomData.foto_kamar}" alt="Kamar ${roomData.nomor_kamar}" class="room-image">`;
                }

                roomDetails.innerHTML = `
                    ${imageHtml}
                    <div class="room-details">
                        <h4>Kamar ${roomData.nomor_kamar} (${roomData.tipe})</h4>
                        <p><strong>Harga:</strong> ${formattedPrice} / malam</p>
                        <p><strong>Status:</strong> ${roomData.status}</p>
                        <p><strong>Kapasitas:</strong> ${roomData.kapasitas} orang</p>
                        <p><strong>Fasilitas:</strong> ${roomData.fasilitas || 'Tidak ada informasi fasilitas'}</p>
                        ${roomData.note ? `<p><strong>Catatan:</strong> ${roomData.note}</p>` : ''}
                    </div>
                `;
                
                // Update price input
                document.getElementById('room_price').value = roomData.harga_per_malam;
                calculateTotalPrice();
            } else {
                roomDetails.innerHTML = `<div class="alert alert-danger">Detail kamar tidak ditemukan</div>`;
            }
        } else {
            roomDetails.innerHTML = `
                <div class="text-center py-4">
                    <p class="text-gray-500 mb-0">Pilih kamar untuk melihat detail</p>
                </div>
            `;
            document.getElementById('room_price').value = '';
            document.getElementById('total_harga').value = '';
            maxCapacityDisplay.textContent = '-';
            jumlahTamuInput.max = '';
        }
    }
    
    // Validate guest input
    function validateGuestInput() {
        const jumlahTamuInput = document.getElementById('jumlah_tamu');
        const roomSelect = document.getElementById('id_kamar');
        
        if (roomSelect.value) {
            const selectedOption = roomSelect.options[roomSelect.selectedIndex];
            const maxCapacity = parseInt(selectedOption.dataset.capacity);
            const currentValue = parseInt(jumlahTamuInput.value) || 0;
            
            if (currentValue > maxCapacity) {
                showNotification(`Maksimal tamu untuk kamar ini adalah ${maxCapacity} orang`);
                jumlahTamuInput.value = maxCapacity;
            } else if (currentValue < 1) {
                jumlahTamuInput.value = 1;
            }
        }
    }
    
    // Event listeners
    const roomSelect = document.getElementById('id_kamar');
    if (roomSelect) {
        roomSelect.addEventListener('change', function() {
            updateRoomInfo();
        });
        
        // Trigger change event to initialize room details if a room is selected
        if (roomSelect.value) {
            roomSelect.dispatchEvent(new Event('change'));
        }
    }
    
    const checkinInput = document.getElementById('tanggal_checkin');
    const checkoutInput = document.getElementById('tanggal_checkout');
    
    if (checkinInput && checkoutInput) {
        checkinInput.addEventListener('change', calculateTotalPrice);
        checkoutInput.addEventListener('change', calculateTotalPrice);
    }
    
    // Show/hide payment proof upload based on payment method
    const paymentMethodSelect = document.getElementById('metode_pembayaran');
    const paymentProofContainer = document.getElementById('payment_proof_container');
    
    if (paymentMethodSelect && paymentProofContainer) {
        paymentMethodSelect.addEventListener('change', function() {
            if (this.value === 'Transfer') {
                paymentProofContainer.style.display = 'block';
                document.getElementById('bukti_pembayaran').setAttribute('required', 'required');
            } else {
                paymentProofContainer.style.display = 'none';
                document.getElementById('bukti_pembayaran').removeAttribute('required');
            }
        });
    }
    
    // Validate jumlah tamu input
    const jumlahTamuInput = document.getElementById('jumlah_tamu');
    if (jumlahTamuInput) {
        jumlahTamuInput.addEventListener('input', function() {
            validateGuestInput();
        });
        
        jumlahTamuInput.addEventListener('change', function() {
            validateGuestInput();
        });
        
        jumlahTamuInput.addEventListener('keydown', function(e) {
            const roomSelect = document.getElementById('id_kamar');
            if (roomSelect.value) {
                const selectedOption = roomSelect.options[roomSelect.selectedIndex];
                const maxCapacity = parseInt(selectedOption.dataset.capacity);
                const currentValue = parseInt(this.value) || 0;
                
                // Prevent increasing beyond max capacity with up arrow
                if (e.key === 'ArrowUp' && currentValue >= maxCapacity) {
                    e.preventDefault();
                    this.value = maxCapacity;
                    showNotification(`Maksimal tamu untuk kamar ini adalah ${maxCapacity} orang`);
                }
                
                // Prevent decreasing below 1 with down arrow
                if (e.key === 'ArrowDown' && currentValue <= 1) {
                    e.preventDefault();
                    this.value = 1;
                }
            }
        });
    }
    
    // Validate form submission
    const bookingForm = document.querySelector('form');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            const roomSelect = document.getElementById('id_kamar');
            const jumlahTamu = document.getElementById('jumlah_tamu').value;
            
            if (roomSelect.value) {
                const selectedOption = roomSelect.options[roomSelect.selectedIndex];
                const roomCapacity = selectedOption.dataset.capacity;
                
                if (parseInt(jumlahTamu) > parseInt(roomCapacity)) {
                    e.preventDefault();
                    showNotification(`Jumlah tamu melebihi kapasitas kamar. Maksimal ${roomCapacity} orang`);
                }
            }
        });
    }
});
</script>
</body>
</html>