<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user is logged in as guest
if (!isGuestLoggedIn()) {
    redirect('guest_login.php');
}

global $pdo;

// Proses pembatalan jika ada parameter cancel
if (isset($_GET['cancel_id'])) {
    $cancelId = $_GET['cancel_id'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM pemesanan WHERE id_pemesanan = ? AND id_tamu = ?");
        $stmt->execute([$cancelId, $_SESSION['tamu_id']]);
        $booking = $stmt->fetch();

        if ($booking && in_array($booking['status'], ['Menunggu', 'Dikonfirmasi'])) {
            $stmt = $pdo->prepare("UPDATE pemesanan SET status = 'Dibatalkan' WHERE id_pemesanan = ?");
            $stmt->execute([$cancelId]);
            echo "<script>alert('Pemesanan berhasil dibatalkan'); window.location.href='index.php?page=guest/dashboard';</script>";
            exit;
        }
    } catch (PDOException $e) {
        die("Database error: " . $e->getMessage());
    }
}

// Get guest data
try {
    $stmt = $pdo->prepare("SELECT * FROM tamu WHERE id_tamu = ?");
    $stmt->execute([$_SESSION['tamu_id']]);
    $guest = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT p.*, k.nomor_kamar, k.tipe, k.foto_kamar
        FROM pemesanan p
        JOIN kamar k ON p.id_kamar = k.id_kamar
        WHERE p.id_tamu = ?
        ORDER BY p.tanggal_checkin DESC
        LIMIT 5
    ");
    $stmt->execute([$_SESSION['tamu_id']]);
    $bookings = $stmt->fetchAll();

    $stmt = $pdo->query("
        SELECT * FROM kamar 
        ORDER BY harga_per_malam ASC
        LIMIT 12
    ");
    $allRooms = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Selamat Datang, <?= $guest['nama_lengkap'] ?></h1>
        <a href="index.php?page=guest/pemesanan" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-calendar fa-sm text-white-50"></i> Pesan Kamar
        </a>
    </div>

    <div class="row">
        <!-- Total Pemesanan -->
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Pemesanan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= count($bookings) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kunjungan Mendatang -->
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Kunjungan Mendatang</div>
                            <?php
                            $upcomingStays = 0;
                            foreach ($bookings as $booking) {
                                if ($booking['status'] === 'Dikonfirmasi' || $booking['status'] === 'Menunggu') {
                                    $upcomingStays++;
                                }
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $upcomingStays ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-hotel fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status Kunjungan -->
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Status Kunjungan Saat Ini</div>
                            <?php
                            $currentStay = false;
                            foreach ($bookings as $booking) {
                                if ($booking['status'] === 'Check-In') {
                                    $currentStay = true;
                                    break;
                                }
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $currentStay ? 'Sedang Menginap' : 'Belum Check-In' ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-bed fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pemesanan Terbaru -->
    <div class="card shadow mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Pemesanan Terbaru Anda</h6>
            <a href="index.php?page=guest/bookings" class="btn btn-sm btn-primary">Lihat Semua</a>
        </div>
        <div class="card-body">
            <?php if (empty($bookings)): ?>
                <div class="text-center py-4">
                    <p class="text-gray-500 mb-0">Anda belum memiliki pemesanan apapun.</p>
                    <a href="index.php?page=guest/pemesanan">Pesan kamar pertama Anda sekarang</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Kamar</th>
                                <th>Check-In</th>
                                <th>Check-Out</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?= $booking['nomor_kamar'] ?> (<?= $booking['tipe'] ?>)</td>
                                <td><?= formatDate($booking['tanggal_checkin']) ?></td>
                                <td><?= formatDate($booking['tanggal_checkout']) ?></td>
                                <td><?= formatCurrency($booking['total_harga']) ?></td>
                                <td><span class="badge bg-<?= 
                                    $booking['status'] === 'Menunggu' ? 'warning' : 
                                    ($booking['status'] === 'Dikonfirmasi' ? 'info' : 
                                    ($booking['status'] === 'Check-In' ? 'success' : 
                                    ($booking['status'] === 'Selesai' ? 'primary' : 
                                    ($booking['status'] === 'Dibatalkan' ? 'danger' : 'secondary')))) ?>">
                                    <?= $booking['status'] ?>
                                </span></td>
                                <td>
                                    <?php if (in_array($booking['status'], ['Menunggu', 'Dikonfirmasi'])): ?>
                                        <a href="index.php?page=guest/dashboard&cancel_id=<?= $booking['id_pemesanan'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin membatalkan pemesanan ini?')">
                                            Batalkan
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>Batalkan</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Semua Kamar -->
    <div class="card shadow mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary">Semua Kamar Hotel</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <?php if (empty($allRooms)): ?>
                    <div class="col-12 text-center py-4">
                        <p class="text-gray-500 mb-0">Tidak ada kamar yang tersedia saat ini.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($allRooms as $room): ?>
                    <?php 
                        $isAvailable = ($room['status'] === 'Tersedia');
                        $statusText = $isAvailable ? 'Tersedia' : 'Tidak Tersedia';
                        $statusClass = $isAvailable ? '' : 'room-unavailable';
                        $maintenanceNote = ($room['status'] === 'Maintenance' && !empty($room['note'])) ? $room['note'] : '';
                    ?>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card room-card h-100 <?= $statusClass ?>">
                            <?php if (!$isAvailable): ?>
                            <div class="room-status-overlay">
                                <span class="badge bg-secondary"><?= $room['status'] ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($room['foto_kamar'])): ?>
                            <img src="uploads/rooms/<?= $room['foto_kamar'] ?>" class="card-img-top room-image" style="height: 180px; object-fit: cover;">
                            <?php else: ?>
                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 180px;">
                                <i class="bi bi-card-image text-muted" style="font-size: 3rem;"></i>
                            </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title">
                                    Kamar <?= $room['nomor_kamar'] ?>
                                    <span class="badge bg-<?= $isAvailable ? 'success' : 'secondary' ?> float-end"><?= $statusText ?></span>
                                </h5>
                                <h6 class="card-subtitle mb-2 text-muted"><?= $room['tipe'] ?></h6>
                                <?php if (!empty($maintenanceNote)): ?>
                                <div class="alert alert-warning py-1 px-2 mb-2" style="font-size: 0.8rem;">
                                    <i class="bi bi-exclamation-triangle-fill"></i> <?= $maintenanceNote ?>
                                </div>
                                <?php endif; ?>
                                <p class="card-text" style="height: 60px; overflow: hidden;">
                                    <?= $room['fasilitas'] ?: 'Tidak ada detail fasilitas tersedia' ?>
                                </p>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="text-primary font-weight-bold">
                                        <?= formatCurrency($room['harga_per_malam']) ?> /malam
                                    </span>
                                    <span class="badge badge-pill" style="background-color: #e3f2fd; color: #1976d2;">
                                        <i class="fas fa-users mr-1"></i> Kapasitas: <?= $room['kapasitas'] ?>
                                    </span>
                                </div>
                                <div class="d-grid mt-3">
                                    <?php if ($isAvailable): ?>
                                    <a href="index.php?page=guest/pemesanan&room=<?= $room['id_kamar'] ?>" class="btn btn-primary btn-sm">Pesan Sekarang</a>
                                    <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>Tidak Tersedia</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>